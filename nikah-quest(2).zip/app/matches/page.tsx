import MatchesAndMessages from '@/components/MatchesAndMessages'
import { HomeButton } from '@/components/HomeButton'

export default function MatchesPage() {
  return (
    <div className="relative">
      <HomeButton />
      <MatchesAndMessages />
    </div>
  )
}

