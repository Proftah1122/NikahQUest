import { HowItWorksContent } from '@/components/HowItWorksContent'
import { HomeButton } from '@/components/HomeButton'

export default function HowItWorksPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <HomeButton />
      <HowItWorksContent />
    </div>
  )
}

