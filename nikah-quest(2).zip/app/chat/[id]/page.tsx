'use client'

import { useParams, useRouter } from 'next/navigation'
import ChatScreen from '@/components/ChatScreen'
import { HomeButton } from '@/components/HomeButton'

// Mock data for Aisha's profile
const aishaProfile = {
  id: '1',
  name: 'Aisha',
  photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg'
}

export default function ChatPage() {
  const params = useParams()
  const router = useRouter()
  const matchId = params.id as string

  // In a real application, you would fetch the match data based on the ID
  // For now, we're using mock data
  const match = {
    id: matchId,
    name: 'Aisha',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg'
  }

  if (!match) {
    // Handle the case where the match is not found
    return <div>Match not found</div>
  }

  return (
    <div className="relative">
      <HomeButton />
      <ChatScreen
        matchId={match.id}
        matchName={match.name}
        matchPhoto={match.photo}
      />
    </div>
  )
}

