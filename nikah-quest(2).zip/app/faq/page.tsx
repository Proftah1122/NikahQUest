import { FAQContent } from '@/components/FAQContent'
import { HomeButton } from '@/components/HomeButton'

export default function FAQPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <HomeButton />
      <FAQContent />
    </div>
  )
}

