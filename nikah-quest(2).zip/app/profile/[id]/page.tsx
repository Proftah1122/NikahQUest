'use client'

import { useParams } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowLeft, MapPin, Briefcase, Book, Heart, Users, Globe, GraduationCap, Moon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { EnlargedImage } from '@/components/EnlargedImage'
import { HomeButton } from '@/components/HomeButton'

// Aisha's profile data
const aishaProfile = {
  id: '1',
  name: 'Aisha',
  photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg',
  age: 25,
  occupation: 'Nurse',
  location: 'Lagos, Nigeria',
  bio: 'Dedicated nurse looking for a life partner who values faith and family. Not open to polygamy.',
  interests: ['Healthcare', 'Reading', 'Cooking', 'Islamic studies'],
  preferences: {
    polygamy: 'Not open',
    maritalStatus: 'Never married',
    ageRange: '30-40',
    location: 'Lagos, Nigeria',
    occupation: 'Doctor',
    religiosity: 'Practicing Muslim',
  },
  religiousBackground: {
    sect: 'Sunni',
    prayerHabits: '5 times a day',
    quranKnowledge: 'Good',
  },
  education: 'Bachelor of Science in Nursing',
  familyBackground: 'Close-knit family, both parents still alive',
  languages: ['English', 'Yoruba'],
  additionalInfo: {
    hobbies: ['Reading', 'Cooking', 'Traveling'],
    favoriteIslamicScholars: ['Shaykh Hamza Yusuf', 'Shaykh Yasir Qadhi'],
    lifeGoals: ['To have a happy family', 'To serve my community'],
  }
}

export default function ProfilePage() {
  const params = useParams()
  const profileId = params.id as string

  // In a real application, you would fetch the profile data based on the ID
  // For now, we're always using Aisha's profile
  const profile = aishaProfile

  const router = useRouter()
  const [showEnlargedImage, setShowEnlargedImage] = useState(false)

  const handleSendMessage = () => {
    router.push(`/chat/${profile.id}`)
  }

  const toggleEnlargedImage = () => {
    setShowEnlargedImage(!showEnlargedImage)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-blue-50 p-4">
      <HomeButton />
      <Link href="/matches">
        <Button variant="ghost" size="icon" className="mb-4">
          <ArrowLeft className="h-6 w-6" />
        </Button>
      </Link>
      <div className="mx-auto max-w-2xl space-y-6">
        {/* Profile Header */}
        <Card className="overflow-hidden">
          <div className="relative h-48 w-full cursor-pointer" onClick={toggleEnlargedImage}>
            <Image
              src={profile.photo}
              alt={profile.name}
              layout="fill"
              objectFit="cover"
            />
          </div>
          <CardContent className="relative -mt-16 bg-white bg-opacity-90 p-6">
            <div className="flex items-end justify-between">
              <div>
                <h1 className="text-3xl font-bold">{profile.name}</h1>
                <p className="text-lg text-gray-600">{profile.age} years old</p>
              </div>
              <Button 
                className="bg-gradient-to-r from-pink-500 to-blue-500 text-white"
                onClick={handleSendMessage}
              >
                Send Message
              </Button>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge variant="secondary" className="flex items-center gap-1">
                <MapPin className="h-3 w-3" /> {profile.location}
              </Badge>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Briefcase className="h-3 w-3" /> {profile.occupation}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Bio */}
        <Card>
          <CardHeader>
            <CardTitle>About Me</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{profile.bio}</p>
          </CardContent>
        </Card>

        {/* Interests */}
        <Card>
          <CardHeader>
            <CardTitle>Interests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((interest, index) => (
                <Badge key={index} variant="outline">{interest}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Religious Background */}
        <Card>
          <CardHeader>
            <CardTitle>Religious Background</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p><strong>Sect:</strong> {profile.religiousBackground.sect}</p>
            <p><strong>Prayer Habits:</strong> {profile.religiousBackground.prayerHabits}</p>
            <p><strong>Quran Knowledge:</strong> {profile.religiousBackground.quranKnowledge}</p>
          </CardContent>
        </Card>

        {/* Education and Career */}
        <Card>
          <CardHeader>
            <CardTitle>Education and Career</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              {profile.education}
            </p>
            <p className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              {profile.occupation}
            </p>
          </CardContent>
        </Card>

        {/* Family Background */}
        <Card>
          <CardHeader>
            <CardTitle>Family Background</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              {profile.familyBackground}
            </p>
          </CardContent>
        </Card>

        {/* Languages */}
        <Card>
          <CardHeader>
            <CardTitle>Languages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {profile.languages.map((language, index) => (
                <Badge key={index} variant="secondary">
                  <Globe className="mr-1 h-3 w-3" /> {language}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p><strong>Age Range:</strong> {profile.preferences.ageRange}</p>
            <p><strong>Location:</strong> {profile.preferences.location}</p>
            <p><strong>Occupation:</strong> {profile.preferences.occupation}</p>
            <p><strong>Polygamy:</strong> {profile.preferences.polygamy}</p>
            <p><strong>Marital Status:</strong> {profile.preferences.maritalStatus}</p>
            <p><strong>Religiosity:</strong> {profile.preferences.religiosity}</p>
          </CardContent>
        </Card>

        {/* Additional Information */}
        <Card>
          <CardHeader>
            <CardTitle>Additional Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold">Hobbies</h4>
              <div className="flex flex-wrap gap-2 mt-2">
                {profile.additionalInfo.hobbies.map((hobby, index) => (
                  <Badge key={index} variant="outline">{hobby}</Badge>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold">Favorite Islamic Scholars</h4>
              <ul className="list-disc list-inside mt-2">
                {profile.additionalInfo.favoriteIslamicScholars.map((scholar, index) => (
                  <li key={index}>{scholar}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold">Life Goals</h4>
              <ul className="list-disc list-inside mt-2">
                {profile.additionalInfo.lifeGoals.map((goal, index) => (
                  <li key={index}>{goal}</li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
      {showEnlargedImage && (
        <EnlargedImage
          src={profile.photo}
          alt={profile.name}
          onClose={toggleEnlargedImage}
        />
      )}
    </div>
  )
}

