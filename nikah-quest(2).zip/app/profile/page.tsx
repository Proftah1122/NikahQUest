import { ProfileScreen } from '@/components/ProfileScreen'
import { HomeButton } from '@/components/HomeButton'

export default function ProfilePage() {
  return (
    <div className="relative">
      <HomeButton />
      <ProfileScreen />
    </div>
  )
}

