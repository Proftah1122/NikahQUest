import { SignIn } from '@/components/auth/SignIn'
import { HomeButton } from '@/components/HomeButton'

export default function SignInPage() {
  return (
    <div className="relative">
      <HomeButton />
      <SignIn />
    </div>
  )
}

