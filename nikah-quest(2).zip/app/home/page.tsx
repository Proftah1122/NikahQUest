import HomeExploreScreen from '@/components/HomeExploreScreen'

export default function HomePage() {
  return <HomeExploreScreen />
}

