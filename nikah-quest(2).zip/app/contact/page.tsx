import { ContactContent } from '@/components/ContactContent'
import { HomeButton } from '@/components/HomeButton'

export default function ContactPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <HomeButton />
      <ContactContent />
    </div>
  )
}

