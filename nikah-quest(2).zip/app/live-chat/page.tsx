import { LiveChatContent } from '@/components/LiveChatContent'
import { HomeButton } from '@/components/HomeButton'

export default function LiveChatPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <HomeButton />
      <LiveChatContent />
    </div>
  )
}

