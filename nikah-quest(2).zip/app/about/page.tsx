import { AboutUsContent } from '@/components/AboutUsContent'
import { HomeButton } from '@/components/HomeButton'

export default function AboutPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <HomeButton />
      <AboutUsContent />
    </div>
  )
}

