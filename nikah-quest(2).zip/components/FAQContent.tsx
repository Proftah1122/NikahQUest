'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown, ChevronUp } from 'lucide-react'

const faqs = [
  {
    question: "What is NikahQuest?",
    answer: "NikahQuest is a Muslim-centered matchmaking platform designed to help singles connect and build meaningful, halal relationships. We combine modern technology with Islamic values to make the process easy, secure, and faith-based."
  },
  {
    question: "How does NikahQuest ensure Islamic values are upheld?",
    answer: "Our platform is designed to align with Islamic principles. Features like modest profiles, meaningful bios, respectful communication, and Quranic and Hadith guidance help users stay true to their faith while navigating the matchmaking process."
  },
  {
    question: "Is NikahQuest available worldwide?",
    answer: "Yes! NikahQuest is open to Muslims globally. We aim to connect users from all parts of the world while maintaining the same high standard of user experience and faith-based principles."
  },
  {
    question: "How do I get started?",
    answer: "Getting started is easy: 1) Download the app or visit our website. 2) Create an account. 3) Complete your profile by adding details about yourself and what you're looking for in a partner. 4) Start browsing profiles and finding meaningful connections."
  },
  {
    question: "Is my information secure?",
    answer: "Absolutely. At NikahQuest, your privacy and security are our top priorities. We use advanced encryption and privacy settings to ensure your data is protected at all times."
  },
  {
    question: "Can I report inappropriate behavior?",
    answer: "Yes. We have a strict code of conduct, and users can report any inappropriate behavior directly through the app. Our team takes these reports seriously and takes prompt action to maintain a safe environment."
  },
  {
    question: "How does the matching process work?",
    answer: "NikahQuest uses a sophisticated matching algorithm that considers your preferences, values, and compatibility factors. When two users express mutual interest, it results in a match, and you can start a conversation."
  },
  {
    question: "What happens if I'm matched with someone?",
    answer: "When you and another user express interest in each other, you'll receive a celebratory match notification. From there, you can start a respectful conversation to explore compatibility further."
  },
  {
    question: "Can I see someone's full profile before matching?",
    answer: "Yes. By clicking on the bio icon at the bottom right of a person's profile picture, you can view their full profile details, which slide in smoothly without disrupting the overall layout."
  },
  {
    question: "What if I don't find a match right away?",
    answer: "Patience is key. NikahQuest provides reminders through Quranic verses and Hadiths to encourage hope and trust in Allah's timing. Keep exploring profiles, and Insha'Allah, the right match will come at the right time."
  },
  {
    question: "Is there a subscription fee to use NikahQuest?",
    answer: "NikahQuest offers both free and premium features. The free version allows you to create a profile, browse users, and match with others. Premium features, such as advanced filters and priority visibility, may come at an additional cost."
  },
  {
    question: "Can I delete my account?",
    answer: "Yes. If you no longer wish to use NikahQuest, you can delete your account directly from the app. All your data will be permanently removed from our servers."
  },
  {
    question: "Are divorced or widowed individuals welcome on NikahQuest?",
    answer: "Of course! NikahQuest is open to Muslims from all walks of life, regardless of marital status. Everyone deserves a second chance at love and companionship."
  },
  {
    question: "How are Quranic verses and Hadiths integrated into the app?",
    answer: "Quranic verses and Hadiths related to marriage, patience, and hope are displayed throughout the app in subtle, visually appealing ways, particularly in the hero section and during key moments like matches."
  },
  {
    question: "Can families be involved in the process?",
    answer: "Yes, we encourage involving families in the process once you and your match are ready. This aligns with Islamic values and ensures transparency and support in your journey."
  },
  {
    question: "What if I need help or technical support?",
    answer: "If you have any questions or technical issues, you can contact our support team via the app or website. We are here to assist you every step of the way."
  },
  {
    question: "Does NikahQuest offer marriage counseling or advice?",
    answer: "While NikahQuest is primarily a matchmaking platform, we share content and resources on building successful relationships based on Islamic principles. Counseling services may be added in future updates."
  },
  {
    question: "Is NikahQuest suitable for young Muslims or older adults?",
    answer: "Yes! NikahQuest is designed for all age groups seeking halal companionship, whether you're a young adult or an older Muslim looking for a life partner."
  },
  {
    question: "Can I update my profile information later?",
    answer: "Yes. You can update your profile details at any time to reflect changes or provide additional information."
  },
  {
    question: "How can I give feedback about NikahQuest?",
    answer: "We value your input! You can share your feedback or suggestions through the app or by contacting our support team. Your insights help us improve and serve you better."
  }
]

export function FAQContent() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <div className="container mx-auto px-4 py-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Frequently Asked Questions
      </motion.h1>
      
      <motion.p 
        className="text-lg text-center mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Here are answers to some of the most commonly asked questions about NikahQuest:
      </motion.p>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <motion.div 
            key={index}
            className="bg-gray-800 rounded-lg overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 * index }}
          >
            <button
              className="w-full px-6 py-4 text-left flex justify-between items-center"
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
            >
              <span className="font-semibold">{faq.question}</span>
              {openIndex === index ? (
                <ChevronUp className="h-5 w-5" />
              ) : (
                <ChevronDown className="h-5 w-5" />
              )}
            </button>
            <AnimatePresence>
              {openIndex === index && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-6 pb-4"
                >
                  <p className="text-gray-300">{faq.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>

      <motion.p 
        className="text-center mt-12 text-gray-300"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      >
        If you have more questions, feel free to reach out to us. We're here to support your journey toward a blessed and fulfilling relationship!
      </motion.p>
    </div>
  )
}

