'use client'

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

interface BackButtonProps {
  className?: string;
}

export function BackButton({ className = '' }: BackButtonProps) {
  const router = useRouter()

  return (
    <Button
      variant="ghost"
      size="icon"
      className={`absolute top-4 left-4 z-50 ${className}`}
      onClick={() => router.back()}
    >
      <ArrowLeft className="h-6 w-6" />
    </Button>
  )
}

