'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import NavMenu from './NavMenu'
import { QuranHadithOverlay } from './QuranHadithOverlay'

export default function Hero() {
  const [isVideoLoaded, setIsVideoLoaded] = useState(false)

  useEffect(() => {
    const video = document.querySelector('video')
    if (video) {
      video.addEventListener('loadeddata', () => setIsVideoLoaded(true))
    }
  }, [])

  return (
    <div className="relative h-screen w-full overflow-hidden bg-black">
      {/* Video Background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${
          isVideoLoaded ? 'opacity-50' : 'opacity-0'
        }`}
      >
        <source src="https://res.cloudinary.com/df7a0vgug/video/upload/v1735466990/228285_medium_i2ddzb.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Navigation Menu */}
      <NavMenu />

      {/* Content Overlay */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 pb-20 text-center text-white">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-4 text-5xl font-bold tracking-tight md:text-6xl lg:text-7xl"
        >
          <span className="bg-gradient-to-r from-[#FF1493] to-[#1E90FF] bg-clip-text text-transparent">
            NikahQuest
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-8 text-xl font-light md:text-2xl"
        >
          Where Faith meets Forever
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0"
        >
          <Link
            href="/signup"
            className="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-[#FF1493] to-[#1E90FF] p-0.5 text-sm font-medium text-gray-900 hover:text-white focus:outline-none focus:ring-4 focus:ring-[#FF1493]/50"
          >
            <span className="relative rounded-full bg-white px-5 py-2.5 transition-all duration-75 ease-in group-hover:bg-opacity-0">
              Begin Your Journey
            </span>
          </Link>
          <Link
            href="/signin"
            className="group relative inline-flex items-center justify-center overflow-hidden rounded-full p-0.5 text-sm font-medium text-gray-900 hover:text-white focus:outline-none focus:ring-4 focus:ring-blue-300"
          >
            <span className="relative rounded-full bg-white px-5 py-2.5 text-gray-900 transition-all duration-75 ease-in group-hover:bg-opacity-0 group-hover:text-white">
              Sign In
            </span>
          </Link>
        </motion.div>
      </div>

      {/* Quranic Verses & Hadith Overlay */}
      <div className="absolute bottom-4 left-4 z-20">
        <QuranHadithOverlay />
      </div>

      {/* Glowing Neon Accent */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#FF1493] via-[#1E90FF] to-[#FF1493]"></div>
    </div>
  )
}

