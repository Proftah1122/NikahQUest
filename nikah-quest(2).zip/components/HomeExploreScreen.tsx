'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { User, MessageSquare, Settings, Info, LogOut } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import BioPanel from './BioPanel'
import MatchNotification from './MatchNotification'
import { SwipeableCard } from './SwipeableCard'
import { InteractiveButtons } from './InteractiveButtons'
import { MatchRecommendations } from './MatchRecommendations'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type Profile = {
  id: number
  name: string
  age: number
  occupation: string
  location: string
  bio: string
  photo: string
  preferences: {
    polygamy: string
    maritalStatus: string
    ageRange: string
  }
  interests: string[]
  verified: boolean
  gender: 'male' | 'female'
}

// Updated mock data for profiles
const profiles: Profile[] = [
  {
    id: 1,
    name: 'Aisha Jinadu',
    age: 25,
    occupation: 'Nurse',
    location: 'Lagos, Nigeria',
    bio: 'Dedicated nurse looking for a life partner who values faith and family. Not open to polygamy.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '30-40',
    },
    interests: ['Healthcare', 'Reading', 'Cooking', 'Islamic studies'],
    verified: true,
    gender: 'female',
  },
  {
    id: 2,
    name: 'Zinat',
    age: 27,
    occupation: 'Software Developer',
    location: 'California, USA',
    bio: 'Tech-savvy muslimah, open to polygamy. Mother of two looking for a loving family.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048954524749304_bkkare.jpg',
    preferences: {
      polygamy: 'Open',
      maritalStatus: 'Married with children',
      ageRange: '28-40',
    },
    interests: ['Coding', 'Parenting', 'Technology', 'Outdoor activities'],
    verified: true,
    gender: 'female',
  },
  {
    id: 3,
    name: 'Islamat',
    age: 35,
    occupation: 'Teacher',
    location: 'Toronto, Canada',
    bio: 'Nigerian-born educator seeking to be a second or third wife. Mother of four with a passion for Islamic education.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048954641415959_hsmjyn.jpg',
    preferences: {
      polygamy: 'Seeking to be second or third wife',
      maritalStatus: 'Married with children',
      ageRange: '35-50',
    },
    interests: ['Teaching', 'Islamic education', 'Cooking', 'Family activities'],
    verified: true,
    gender: 'female',
  },
  {
    id: 4,
    name: 'Aisha',
    age: 32,
    occupation: 'Therapist',
    location: 'London, UK',
    bio: 'Egyptian-born therapist living in the UK. Previously married, no children. Looking for a fresh start with a compatible partner.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048954688082621_z7n95p.jpg',
    preferences: {
      polygamy: 'Not specified',
      maritalStatus: 'Divorced',
      ageRange: '30-45',
    },
    interests: ['Psychology', 'Art therapy', 'Traveling', 'Meditation'],
    verified: true,
    gender: 'female',
  },
  {
    id: 5,
    name: 'Fatima',
    age: 29,
    occupation: 'Architect',
    location: 'Dubai, UAE',
    bio: 'Passionate about Islamic architecture and sustainable design. Seeking a partner who appreciates both tradition and innovation.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839332027490_qnoip2.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '28-38',
    },
    interests: ['Architecture', 'Sustainable design', 'Islamic art', 'Photography'],
    verified: true,
    gender: 'female',
  },
  {
    id: 6,
    name: 'Amina',
    age: 31,
    occupation: 'Entrepreneur',
    location: 'Kuala Lumpur, Malaysia',
    bio: 'Founder of a halal cosmetics brand. Looking for a supportive partner who values ambition and faith equally.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839388694151_fjx8xf.jpg',
    preferences: {
      polygamy: 'Open to discussion',
      maritalStatus: 'Never married',
      ageRange: '30-40',
    },
    interests: ['Business', 'Halal industry', 'Skincare', 'Networking'],
    verified: true,
    gender: 'female',
  },
  {
    id: 7,
    name: 'Khadija',
    age: 28,
    occupation: 'Environmental Scientist',
    location: 'Berlin, Germany',
    bio: 'Dedicated to combating climate change through Islamic principles. Seeking a partner who shares my passion for environmental stewardship.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839252027498_o6m0xq.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '27-35',
    },
    interests: ['Environmental science', 'Sustainability', 'Hiking', 'Volunteering'],
    verified: true,
    gender: 'female',
  },
  {
    id: 8,
    name: 'Zainab',
    age: 33,
    occupation: 'Pediatrician',
    location: 'New York, USA',
    bio: 'Devoted to children\'s health and well-being. Looking for a family-oriented partner to build a life with.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839288694161_wloynz.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Divorced',
      ageRange: '32-45',
    },
    interests: ['Pediatrics', 'Child development', 'Fitness', 'Healthy cooking'],
    verified: true,
    gender: 'female',
  },
  {
    id: 9,
    name: 'Ahmed',
    age: 30,
    occupation: 'Software Engineer',
    location: 'Dubai, UAE',
    bio: 'Tech enthusiast and devout Muslim seeking a life partner to build a strong, faith-centered family.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843875360369_qkdxs2.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '25-35',
    },
    interests: ['Technology', 'Islamic studies', 'Fitness', 'Travel'],
    verified: true,
    gender: 'male',
  },
  {
    id: 10,
    name: 'Yusuf',
    age: 35,
    occupation: 'Doctor',
    location: 'London, UK',
    bio: 'Compassionate physician looking for a partner to share life\'s journey and grow in faith together.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843888693701_emqhrg.jpg',
    preferences: {
      polygamy: 'Open to discussion',
      maritalStatus: 'Divorced',
      ageRange: '30-40',
    },
    interests: ['Medicine', 'Charity work', 'Reading', 'Cooking'],
    verified: true,
    gender: 'male',
  },
  {
    id: 11,
    name: 'Omar',
    age: 28,
    occupation: 'Entrepreneur',
    location: 'New York, USA',
    bio: 'Ambitious business owner seeking a supportive partner to build a successful life and family with.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843808693709_smznpm.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '25-35',
    },
    interests: ['Business', 'Networking', 'Sports', 'Personal development'],
    verified: true,
    gender: 'male',
  },
  {
    id: 12,
    name: 'Khalid',
    age: 32,
    occupation: 'University Professor',
    location: 'Toronto, Canada',
    bio: 'Educator and researcher looking for an intellectual partner to share in life\'s adventures and spiritual growth.',
    photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843858693704_ylv4dl.jpg',
    preferences: {
      polygamy: 'Not open',
      maritalStatus: 'Never married',
      ageRange: '28-38',
    },
    interests: ['Academia', 'Literature', 'Art', 'Hiking'],
    verified: true,
    gender: 'male',
  },
]

const HomeExploreScreen = () => {
  const router = useRouter()
  const [currentProfileIndex, setCurrentProfileIndex] = useState(0)
  const [direction, setDirection] = useState<'left' | 'right' | null>(null)
  const [showBio, setShowBio] = useState(false)
  const [showOverlay, setShowOverlay] = useState(false)
  const [showMatchNotification, setShowMatchNotification] = useState(false)
  const [matchedProfile, setMatchedProfile] = useState<Profile | null>(null)

  const currentProfile = profiles[currentProfileIndex]

  const handleSwipe = (swipeDirection: 'left' | 'right') => {
    setDirection(swipeDirection)
    setTimeout(() => {
      setCurrentProfileIndex((prevIndex) => (prevIndex + 1) % profiles.length)
      setDirection(null)
    }, 300)

    // Simulate a match (for demonstration purposes)
    if (swipeDirection === 'right' && Math.random() > 0.5) {
      const oppositeGenderProfiles = profiles.filter(p => p.gender !== currentProfile.gender)
      const randomMatchIndex = Math.floor(Math.random() * oppositeGenderProfiles.length)
      const matchedProfile = oppositeGenderProfiles[randomMatchIndex]
      if (matchedProfile) {
        setMatchedProfile(matchedProfile)
        setShowMatchNotification(true)
      }
    }
  }

  const toggleBio = () => {
    setShowBio((prev) => !prev)
    setShowOverlay((prev) => !prev)
  }

  const handleStartChat = (matchId: number) => {
    router.push(`/chat/${matchId}`)
    setShowMatchNotification(false)
  }

  const handleContinueExploring = () => {
    setShowMatchNotification(false)
  }

  const handleLogout = () => {
  // In a real application, you would call an API to invalidate the session
  console.log('Logging out...')
  // Clear any stored user data or tokens
  localStorage.removeItem('userToken')
  // Redirect to the sign-in page
  router.push('/signin')
}

  return (
    <div className="flex h-screen flex-col bg-gray-100">
      {/* Navigation Bar */}
      <nav className="flex items-center justify-between bg-gradient-to-r from-pink-500 to-blue-500 p-4 shadow-md">
        <Image
          src="https://res.cloudinary.com/df7a0vgug/image/upload/IMG-20250104-WA0013_ovfabx_e_background_removal_f_png_dot770.png"
          alt="NikahQuest Logo"
          width={48}
          height={48}
          className="bg-white rounded-full p-1"
        />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white hover:bg-pink-600">
              <User className="h-6 w-6" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-white">
            <DropdownMenuItem asChild>
              <Link href="/profile" className="flex items-center">
                <User className="mr-2 h-4 w-4" />
                <span>My Profile</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/matches" className="flex items-center">
                <MessageSquare className="mr-2 h-4 w-4" />
                <span>Matches & Messages</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/settings" className="flex items-center">
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </nav>

      {/* Profile Card */}
      <div className="relative flex flex-1 items-center justify-center overflow-hidden">
        <AnimatePresence>
          <motion.div
            key={currentProfile.id}
            className="absolute h-[70vh] w-[90vw] max-w-md overflow-hidden rounded-2xl bg-white shadow-xl z-30"
            initial={{ x: direction === 'right' ? -300 : direction === 'left' ? 300 : 0, opacity: 0, scale: 1 }}
            animate={{ 
              x: 0, 
              opacity: 1, 
              scale: showBio ? 0.9 : 1,
              y: showBio ? -50 : 0
            }}
            exit={{ x: direction === 'left' ? -300 : direction === 'right' ? 300 : 0, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            onDragEnd={(e, { offset, velocity }) => {
              if (offset.x < -100) handleSwipe('left')
              else if (offset.x > 100) handleSwipe('right')
            }}
          >
            <Image
              src={currentProfile.photo}
              alt={currentProfile.name}
              layout="fill"
              objectFit="cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6 text-white">
              <h2 className="text-2xl font-bold">{currentProfile.name}, {currentProfile.age}</h2>
              <p className="text-sm">{currentProfile.occupation} • {currentProfile.location}</p>
              <div className="mt-2 flex space-x-2">
                {currentProfile.verified && (
                  <span className="rounded-full bg-green-500 px-2 py-1 text-xs">Verified</span>
                )}
                <span className="rounded-full bg-blue-500 px-2 py-1 text-xs">{currentProfile.preferences.polygamy}</span>
              </div>
              <p className="mt-2 text-sm">{currentProfile.bio}</p>
            </div>
            <motion.button
              className="absolute bottom-4 right-4 rounded-full bg-white bg-opacity-50 p-2 text-white transition-all hover:bg-opacity-100 hover:text-black"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={toggleBio}
            >
              <Info className="h-6 w-6" />
            </motion.button>
          </motion.div>
        </AnimatePresence>
        {showOverlay && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleBio}
          />
        )}
        <AnimatePresence mode="wait">
          {showBio && (
            <motion.div
              className="z-50"
              onClick={(e) => e.stopPropagation()}
            >
              <BioPanel
                profile={currentProfile}
                onClose={toggleBio}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-center space-x-4 bg-white p-4">
        <Button variant="outline" size="icon" className="rounded-full bg-yellow-400 text-white">
          ↩️
        </Button>
        <Button variant="outline" size="icon" className="rounded-full bg-red-500 text-white" onClick={() => handleSwipe('left')}>
          ❌
        </Button>
        <Button variant="outline" size="icon" className="rounded-full bg-blue-500 text-white">
          ⭐
        </Button>
        <Button variant="outline" size="icon" className="rounded-full bg-green-500 text-white" onClick={() => handleSwipe('right')}>
          💚
        </Button>
        <Button variant="outline" size="icon" className="rounded-full bg-purple-500 text-white">
          🌙
        </Button>
      </div>

      {/* Match Notification */}
      <AnimatePresence>
        {showMatchNotification && matchedProfile && (
          <MatchNotification
            user1={currentProfile}
            user2={matchedProfile}
            onStartChat={() => handleStartChat(matchedProfile.id)}
            onContinueExploring={handleContinueExploring}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

export default HomeExploreScreen

