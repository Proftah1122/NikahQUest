import { motion } from 'framer-motion'
import { UserPlus, Search, Heart, MessageCircle, Info, ArrowRight, Sparkles, Book } from 'lucide-react'

const steps = [
  {
    title: "Create Your Profile",
    description: "Sign up and complete your profile with key details about yourself, your values, and what you're looking for in a partner.",
    icon: UserPlus,
  },
  {
    title: "Explore and Discover",
    description: "Browse through profiles of other members who share your faith, values, and interests.",
    icon: Search,
  },
  {
    title: "Faith-Based Matching",
    description: "Our algorithm considers your preferences, compatibility factors, and shared values to recommend profiles.",
    icon: Heart,
  },
  {
    title: "Show Your Interest",
    description: "Swipe right on profiles you're interested in. If they feel the same, you'll receive a celebratory match notification.",
    icon: Sparkles,
  },
  {
    title: "Start the Conversation",
    description: "Once matched, open the chat to start a meaningful conversation while maintaining respect and modesty.",
    icon: MessageCircle,
  },
  {
    title: "Learn More with the Bio Feature",
    description: "Tap the bio icon to reveal a match's full introduction and get a deeper understanding of the person.",
    icon: Info,
  },
  {
    title: "Spiritual Guidance",
    description: "Find Quranic verses and Hadiths displayed throughout the app, offering encouragement and wisdom.",
    icon: Book,
  },
  {
    title: "Take the Next Steps",
    description: "When the time feels right, move forward in building a future together with the support of NikahQuest.",
    icon: ArrowRight,
  },
]

export function HowItWorksContent() {
  return (
    <div className="container mx-auto px-4 py-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        How It Works: NikahQuest
      </motion.h1>
      
      <motion.p 
        className="text-lg text-center mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        At NikahQuest, we've crafted a simple and spiritually uplifting process to help you find a meaningful connection while upholding Islamic values. Here's how to embark on your journey toward a blessed union:
      </motion.p>

      <div className="grid md:grid-cols-2 gap-8">
        {steps.map((step, index) => (
          <motion.div 
            key={index}
            className="bg-gray-800 p-6 rounded-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 * index }}
          >
            <div className="flex items-center mb-4">
              <div className="bg-gradient-to-r from-pink-500 to-blue-500 p-3 rounded-full mr-4">
                <step.icon className="h-6 w-6 text-white" />
              </div>
              <h2 className="text-xl font-semibold">{step.title}</h2>
            </div>
            <p className="text-gray-300">{step.description}</p>
          </motion.div>
        ))}
      </div>

      <motion.section 
        className="mt-16"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      >
        <h2 className="text-2xl font-semibold mb-4 text-center">Why Choose NikahQuest?</h2>
        <ul className="list-disc list-inside space-y-2 text-gray-300">
          <li>Islamic Principles at the Core: Every interaction is designed to honor Islamic teachings.</li>
          <li>Privacy and Respect: Your information is safeguarded, and the app ensures respectful connections.</li>
          <li>Celebratory Matches: Matching moments feel special and memorable.</li>
          <li>User-Friendly Experience: Effortless navigation and innovative features enhance your journey.</li>
        </ul>
      </motion.section>

      <motion.div 
        className="mt-16 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        <h2 className="text-2xl font-semibold mb-4">Join NikahQuest Today</h2>
        <p className="text-lg text-gray-300">
          Your journey toward a fulfilling and halal relationship starts here. Let's build connections that are pleasing to Allah and filled with tranquility, love, and mercy. 🌸
        </p>
      </motion.div>
    </div>
  )
}

