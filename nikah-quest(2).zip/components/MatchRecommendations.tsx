import Image from 'next/image'
import { motion } from 'framer-motion'

interface MatchRecommendation {
  id: string
  name: string
  photo: string
}

interface MatchRecommendationsProps {
  recommendations: MatchRecommendation[]
}

export function MatchRecommendations({ recommendations }: MatchRecommendationsProps) {
  return (
    <div className="mt-8">
      <h2 className="mb-4 text-2xl font-bold text-white">Recommended Matches</h2>
      <div className="flex space-x-4 overflow-x-auto pb-4">
        {recommendations.map((match) => (
          <motion.div
            key={match.id}
            className="flex-shrink-0"
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <Image
              src={match.photo}
              alt={`${match.name}'s profile picture`}
              width={100}
              height={100}
              className="rounded-full"
            />
            <p className="mt-2 text-center text-sm text-white">{match.name}</p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

