'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Eye, EyeOff, Camera, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { BackButton } from './BackButton'

// Mock user data
const initialUserData = {
  name: 'Aisha Mohammed',
  age: 28,
  location: 'Lagos, Nigeria',
  profilePhoto: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg',
  dietaryHabits: 'Strictly Halal',
  familyValues: 'Traditional',
  profession: 'Software Engineer',
  education: "Bachelor's in Computer Science",
  hobbies: ['Reading', 'Cooking', 'Traveling'],
  religiousPractices: 'Prays 5 times a day, fasts during Ramadan',
  relationshipGoals: 'Seeking a life partner for marriage',
  personalValues: 'Honesty, compassion, and continuous self-improvement',
  agePreference: [25, 35],
  sectPreference: 'Sunni',
  locationRadius: 50,
}

export function ProfileScreen() {
  const [userData, setUserData] = useState(initialUserData)
  const [isProfileVisible, setIsProfileVisible] = useState(true)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setUserData({ ...userData, [e.target.name]: e.target.value })
  }

  const handleSaveChanges = () => {
    // In a real app, this would send the updated data to a server
    console.log('Saving changes:', userData)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-blue-50 p-4">
      <BackButton className="text-black" />
      {/* Top Section */}
      <div className="flex justify-end items-center mb-6 mt-4">
        <div className="flex items-center space-x-2">
          <span className="text-black">{isProfileVisible ? 'Visible' : 'Hidden'}</span>
          <Switch
            checked={isProfileVisible}
            onCheckedChange={setIsProfileVisible}
          />
          {isProfileVisible ? (
            <Eye className="h-5 w-5 text-black" />
          ) : (
            <EyeOff className="h-5 w-5 text-black" />
          )}
        </div>
      </div>

      {/* Profile Card */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center">
            <div className="relative mb-4">
              <Image
                src={userData.profilePhoto}
                alt={userData.name}
                width={120}
                height={120}
                className="rounded-full"
              />
              <Button
                size="icon"
                className="absolute bottom-0 right-0 rounded-full bg-pink-500 hover:bg-pink-600"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
            <h2 className="text-2xl font-bold">{userData.name}</h2>
            <p className="text-gray-600">{userData.age} • {userData.location}</p>
            <div className="mt-2 text-center">
              <p><strong>Dietary Habits:</strong> {userData.dietaryHabits}</p>
              <p><strong>Family Values:</strong> {userData.familyValues}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editable Sections */}
      <Tabs defaultValue="photos" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="photos">Photos</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="photos">
          <Card>
            <CardHeader>
              <CardTitle>Manage Photos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="aspect-square bg-gray-200 rounded-lg flex items-center justify-center">
                    {index === 0 ? (
                      <Image
                        src={userData.profilePhoto}
                        alt="Profile"
                        width={120}
                        height={120}
                        className="rounded-lg object-cover w-full h-full"
                      />
                    ) : (
                      <Plus className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>Personal Details</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div>
                  <Label htmlFor="profession">Profession</Label>
                  <Input
                    id="profession"
                    name="profession"
                    value={userData.profession}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="education">Education</Label>
                  <Input
                    id="education"
                    name="education"
                    value={userData.education}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="hobbies">Hobbies</Label>
                  <Input
                    id="hobbies"
                    name="hobbies"
                    value={userData.hobbies.join(', ')}
                    onChange={(e) => setUserData({ ...userData, hobbies: e.target.value.split(', ') })}
                  />
                </div>
                <div>
                  <Label htmlFor="religiousPractices">Religious Practices</Label>
                  <Textarea
                    id="religiousPractices"
                    name="religiousPractices"
                    value={userData.religiousPractices}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="relationshipGoals">Relationship Goals</Label>
                  <Textarea
                    id="relationshipGoals"
                    name="relationshipGoals"
                    value={userData.relationshipGoals}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="personalValues">Personal Values</Label>
                  <Textarea
                    id="personalValues"
                    name="personalValues"
                    value={userData.personalValues}
                    onChange={handleInputChange}
                  />
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Match Preferences</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div>
                  <Label>Age Range</Label>
                  <Slider
                    min={18}
                    max={80}
                    step={1}
                    value={userData.agePreference}
                    onValueChange={(value) => setUserData({ ...userData, agePreference: value })}
                    className="mt-2"
                  />
                  <div className="flex justify-between mt-1">
                    <span>{userData.agePreference[0]}</span>
                    <span>{userData.agePreference[1]}</span>
                  </div>
                </div>
                <div>
                  <Label htmlFor="sectPreference">Sect Preference</Label>
                  <Select
                    value={userData.sectPreference}
                    onValueChange={(value) => setUserData({ ...userData, sectPreference: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select sect preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Sunni">Sunni</SelectItem>
                      <SelectItem value="Shia">Shia</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                      <SelectItem value="No Preference">No Preference</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Location Radius (km)</Label>
                  <Slider
                    min={1}
                    max={500}
                    step={1}
                    value={[userData.locationRadius]}
                    onValueChange={(value) => setUserData({ ...userData, locationRadius: value[0] })}
                    className="mt-2"
                  />
                  <div className="text-center mt-1">
                    <span>{userData.locationRadius} km</span>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6">
        <Button onClick={handleSaveChanges} className="w-full bg-gradient-to-r from-pink-500 to-blue-500 text-white">
          Save Changes
        </Button>
      </div>
    </div>
  )
}

