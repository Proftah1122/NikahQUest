import { motion } from 'framer-motion'
import { X, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface BioPanelProps {
  profile: {
    name: string
    age: number
    occupation: string
    location: string
    bio: string
    preferences: {
      polygamy: string
      maritalStatus: string
      ageRange: string
    }
    interests?: string[]
  }
  onClose: () => void
}

const BioPanel: React.FC<BioPanelProps> = ({ profile, onClose }) => {
  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="absolute bottom-0 left-0 right-0 h-[70%] rounded-t-3xl bg-white shadow-lg"
    >
      <div className="flex h-full flex-col overflow-hidden">
        <div className="flex items-center justify-between border-b border-pink-100 p-4">
          <h2 className="text-2xl font-bold text-gray-800">{profile.name}'s Bio</h2>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Collapse">
              <ChevronDown className="h-6 w-6" />
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
              <X className="h-6 w-6" />
            </Button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <section className="mb-4">
            <h3 className="mb-2 text-lg font-semibold text-pink-600">About Me</h3>
            <p className="text-gray-700">{profile.bio}</p>
          </section>
          <section className="mb-4">
            <h3 className="mb-2 text-lg font-semibold text-pink-600">Personal Details</h3>
            <ul className="list-inside list-disc text-gray-700">
              <li>Age: {profile.age}</li>
              <li>Occupation: {profile.occupation}</li>
              <li>Location: {profile.location}</li>
              <li>Marital Status: {profile.preferences.maritalStatus}</li>
              <li>Polygamy: {profile.preferences.polygamy}</li>
              <li>Preferred Age Range: {profile.preferences.ageRange}</li>
            </ul>
          </section>
          {profile.interests && (
            <section className="mb-4">
              <h3 className="mb-2 text-lg font-semibold text-pink-600">Interests</h3>
              <div className="flex flex-wrap gap-2">
                {profile.interests.map((interest, index) => (
                  <span key={index} className="rounded-full bg-pink-100 px-3 py-1 text-sm text-pink-800">
                    {interest}
                  </span>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </motion.div>
  )
}

export default BioPanel

