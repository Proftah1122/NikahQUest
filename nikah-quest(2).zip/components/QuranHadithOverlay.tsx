'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, Info, Share2, Bookmark } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

interface Verse {
  id: number
  text: string
  source: string
  type: 'quran' | 'hadith'
}

const verses: Verse[] = [
  // Quranic Verses
  {
    id: 1,
    text: "And among His signs is this: He created for you mates from among yourselves, that you may find tranquility in them; and He placed between you love and mercy. Verily, in that are signs for a people who reflect.",
    source: "Quran 30:21",
    type: 'quran'
  },
  {
    id: 2,
    text: "It may be that you dislike a thing and Allah brings through it a great deal of good.",
    source: "Quran 4:19",
    type: 'quran'
  },
  {
    id: 3,
    text: "So be patient. Indeed, the promise of Allah is truth.",
    source: "Quran 30:60",
    type: 'quran'
  },
  {
    id: 4,
    text: "If they are poor, Allah will enrich them from His bounty. And Allah is all-Encompassing and Knowing.",
    source: "Quran 24:32",
    type: 'quran'
  },
  {
    id: 5,
    text: "Is there any reward for good other than good?",
    source: "Quran 55:60",
    type: 'quran'
  },
  {
    id: 6,
    text: "Our Lord, grant us from among our wives and offspring comfort to our eyes and make us an example for the righteous.",
    source: "Quran 25:74",
    type: 'quran'
  },
  {
    id: 7,
    text: "Indeed, with hardship comes ease.",
    source: "Quran 94:6",
    type: 'quran'
  },
  {
    id: 8,
    text: "And perhaps you love a thing and it is bad for you; and Allah knows, while you know not.",
    source: "Quran 2:216",
    type: 'quran'
  },
  {
    id: 9,
    text: "And whoever relies upon Allah, then He is sufficient for him.",
    source: "Quran 65:3",
    type: 'quran'
  },
  {
    id: 10,
    text: "And live with them in kindness. For if you dislike them – perhaps you dislike a thing and Allah makes therein much good.",
    source: "Quran 4:19",
    type: 'quran'
  },
  {
    id: 11,
    text: "Call upon Me; I will respond to you.",
    source: "Quran 40:60",
    type: 'quran'
  },
  {
    id: 12,
    text: "So do not weaken and do not grieve, and you will be superior if you are believers.",
    source: "Quran 3:139",
    type: 'quran'
  },
  {
    id: 13,
    text: "And He gives you of all that you ask Him. And if you should count the favor of Allah, you could not enumerate them.",
    source: "Quran 14:34",
    type: 'quran'
  },
  {
    id: 14,
    text: "Verily, in the remembrance of Allah do hearts find rest.",
    source: "Quran 13:28",
    type: 'quran'
  },
  {
    id: 15,
    text: "Indeed, your Lord is vast in forgiveness.",
    source: "Quran 53:32",
    type: 'quran'
  },
  {
    id: 16,
    text: "And He found you lost and guided [you].",
    source: "Quran 93:7",
    type: 'quran'
  },
  {
    id: 17,
    text: "And whoever fears Allah – He will make for him a way out and will provide for him from where he does not expect.",
    source: "Quran 65:2-3",
    type: 'quran'
  },
  {
    id: 18,
    text: "Everything We created is precisely measured.",
    source: "Quran 54:49",
    type: 'quran'
  },
  {
    id: 19,
    text: "Indeed, Allah is with the patient.",
    source: "Quran 2:153",
    type: 'quran'
  },
  {
    id: 20,
    text: "He knows what is [presently] before them and what will be after them, and they encompass not a thing of His knowledge except for what He wills.",
    source: "Quran 2:255",
    type: 'quran'
  },

  // Hadiths
  {
    id: 21,
    text: "Marriage is part of my Sunnah, and whoever does not follow my Sunnah has nothing to do with me.",
    source: "Sunan Ibn Majah 1846",
    type: 'hadith'
  },
  {
    id: 22,
    text: "Three people have a right upon Allah to help them: the one who gets married desiring chastity...",
    source: "Sunan an-Nasa'i 3215",
    type: 'hadith'
  },
  {
    id: 23,
    text: "No fatigue, nor disease, nor sorrow, nor sadness, nor hurt, nor distress befalls a Muslim, even if it were the prick he receives from a thorn, but that Allah expiates some of his sins for that.",
    source: "Sahih al-Bukhari 5641",
    type: 'hadith'
  },
  {
    id: 24,
    text: "The best of you is the best to his family, and I am the best among you to my family.",
    source: "Sunan al-Tirmidhi 3895",
    type: 'hadith'
  },
  {
    id: 25,
    text: "If you were to rely upon Allah with reliance due to Him, He would provide for you as He provides for the birds. They go out hungry in the morning and come back full in the evening.",
    source: "Sunan Ibn Majah 4164",
    type: 'hadith'
  },
  {
    id: 26,
    text: "A woman is married for four things: her wealth, her family status, her beauty, and her religion. So marry the religious woman, or you may lose.",
    source: "Sahih al-Bukhari 5090",
    type: 'hadith'
  },
  {
    id: 27,
    text: "When a man marries, he has fulfilled half of his religion, so let him fear Allah regarding the remaining half.",
    source: "Sunan al-Tirmidhi 3096",
    type: 'hadith'
  },
  {
    id: 28,
    text: "Supplication is worship.",
    source: "Sunan Ibn Majah 3828",
    type: 'hadith'
  },
  {
    id: 29,
    text: "The most complete of the believers in faith is the one with the best character.",
    source: "Sunan Abu Dawood 4682",
    type: 'hadith'
  },
  {
    id: 30,
    text: "Do not despair of the mercy of Allah.",
    source: "Sahih Muslim 6863",
    type: 'hadith'
  },
  {
    id: 31,
    text: "There is no gift that a father gives his child more virtuous than good manners.",
    source: "Sunan al-Tirmidhi 1952",
    type: 'hadith'
  },
  {
    id: 32,
    text: "If one of you is concerned about a decision he has to make, then let him pray two rak'ahs and say: 'O Allah, guide me in this matter with Your knowledge...'",
    source: "Sahih al-Bukhari 6382",
    type: 'hadith'
  },
  {
    id: 33,
    text: "Be mindful of Allah, and He will take care of you. Be mindful of Allah, and you shall find Him at your side.",
    source: "Sunan al-Tirmidhi 2516",
    type: 'hadith'
  },
  {
    id: 34,
    text: "The believer who has the most perfect faith is the one whose character is the best and who is kindest to his family.",
    source: "Sunan Abu Dawood 4682",
    type: 'hadith'
  },
  {
    id: 35,
    text: "Contentment is a treasure that is never exhausted.",
    source: "Sunan Ibn Majah 4217",
    type: 'hadith'
  },
  {
    id: 36,
    text: "He who does not thank people is not thankful to Allah.",
    source: "Sunan Abi Dawood 4811",
    type: 'hadith'
  },
  {
    id: 37,
    text: "O Allah, I ask You for guidance, piety, chastity, and self-sufficiency.",
    source: "Sahih Muslim 2723",
    type: 'hadith'
  },
  {
    id: 38,
    text: "The strong believer is better and more beloved to Allah than the weak believer, while there is good in both...",
    source: "Sahih Muslim 2664",
    type: 'hadith'
  },
  {
    id: 39,
    text: "The example of the one who remembers Allah and the one who does not is like the living and the dead.",
    source: "Sahih al-Bukhari 6407",
    type: 'hadith'
  },
  {
    id: 40,
    text: "Verily, Allah is shy and generous. He is shy to turn away the hand of His servant when he raises them to Him in supplication.",
    source: "Sunan al-Tirmidhi 3556",
    type: 'hadith'
  },
]

export function QuranHadithOverlay() {
  const [currentVerseIndex, setCurrentVerseIndex] = useState(0)
  const [isSaved, setIsSaved] = useState(false)

  const currentVerse = verses[currentVerseIndex]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVerseIndex((prevIndex) => {
        let nextIndex = (prevIndex + 1) % verses.length
        while (verses[nextIndex].type === verses[prevIndex].type) {
          nextIndex = (nextIndex + 1) % verses.length
        }
        return nextIndex
      })
      setIsSaved(false)
    }, 30000) // 30 seconds

    return () => clearInterval(interval)
  }, [])

  const nextVerse = () => {
    setCurrentVerseIndex((prevIndex) => {
      let nextIndex = (prevIndex + 1) % verses.length
      while (verses[nextIndex].type === verses[prevIndex].type) {
        nextIndex = (nextIndex + 1) % verses.length
      }
      return nextIndex
    })
    setIsSaved(false)
  }

  const prevVerse = () => {
    setCurrentVerseIndex((prevIndex) => {
      let nextIndex = (prevIndex - 1 + verses.length) % verses.length
      while (verses[nextIndex].type === verses[prevIndex].type) {
        nextIndex = (nextIndex - 1 + verses.length) % verses.length
      }
      return nextIndex
    })
    setIsSaved(false)
  }

  const shareVerse = () => {
    if (navigator.share) {
      navigator.share({
        title: `Inspirational ${currentVerse.type === 'quran' ? 'Quranic Verse' : 'Hadith'} from NikahQuest`,
        text: `${currentVerse.text}\n\n${currentVerse.source}`,
        url: 'https://nikahquest.com'
      }).catch(console.error)
    } else {
      console.log('Web Share API not supported')
      // Fallback: You could copy to clipboard or show a modal with the text to copy
    }
  }

  const saveVerse = () => {
    setIsSaved(!isSaved)
    // In a real app, you would save this to user's preferences or local storage
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="absolute bottom-4 left-4 w-64 rounded-lg bg-gradient-to-r from-pink-200/70 to-blue-200/70 p-3 backdrop-blur-sm"
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentVerse.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-xs text-gray-700 line-clamp-4">{currentVerse.text}</p>
          <p className="text-right text-xs text-gray-600 mt-1">{currentVerse.source}</p>
          <p className="text-left text-xs text-gray-500 mt-1 italic">
            {currentVerse.type === 'quran' ? 'Quranic Verse' : 'Hadith'}
          </p>
        </motion.div>
      </AnimatePresence>
      <div className="mt-2 flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={prevVerse}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="flex space-x-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" onClick={shareVerse}>
                  <Share2 className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Share this verse</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" onClick={saveVerse}>
                  <Bookmark className={`h-3 w-3 ${isSaved ? 'fill-current' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isSaved ? 'Unsave this verse' : 'Save this verse'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Info className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>These verses and hadiths are displayed to inspire and guide you in your journey to find a life partner in accordance with Islamic principles.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Button variant="ghost" size="sm" onClick={nextVerse}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </motion.div>
  )
}

