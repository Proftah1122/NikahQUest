'use client'

import { useState } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Search, Settings, Moon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { BackButton } from './BackButton'

// Mock data for matches
const matches = [
  { id: 1, name: 'Aisha', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg', online: true },
  { id: 2, name: 'Fatima', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839332027490_qnoip2.jpg', online: false },
  { id: 3, name: 'Yusuf', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843888693701_emqhrg.jpg', online: true },
  { id: 4, name: 'Omar', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843808693709_smznpm.jpg', online: false },
  { id: 5, name: 'Zainab', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839288694161_wloynz.jpg', online: true },
]

// Mock data for messages
const messages = [
  { id: 1, name: 'Aisha', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28048946594750097_qccurm.jpg', lastMessage: 'Assalamu alaikum! How are you?', unread: true },
  { id: 2, name: 'Yusuf', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843888693701_emqhrg.jpg', lastMessage: 'I enjoyed our conversation yesterday.', unread: false },
  { id: 3, name: 'Fatima', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042839332027490_qnoip2.jpg', lastMessage: 'Would you like to meet for coffee?', unread: true },
  { id: 4, name: 'Omar', photo: 'https://res.cloudinary.com/df7a0vgug/image/upload/Imagine_28042843808693709_smznpm.jpg', lastMessage: 'Thank you for your kind words.', unread: false },
]

const MatchesAndMessages = () => {
  const [selectedMatch, setSelectedMatch] = useState<number | null>(null)

  return (
    <div className="flex h-screen flex-col bg-gray-100">
      <BackButton />
      {/* Navigation Bar */}
      <nav className="flex items-center justify-between bg-gradient-to-r from-pink-500 to-blue-500 p-4 shadow-md">
        <Button variant="secondary" size="icon" className="bg-white text-pink-500 hover:bg-gray-100 hover:text-blue-500">
          <Search className="h-6 w-6" />
        </Button>
        <Image
          src="https://res.cloudinary.com/df7a0vgug/image/upload/IMG-20250104-WA0013_ovfabx_e_background_removal_f_png_dot770.png"
          alt="NikahQuest Logo"
          width={48}
          height={48}
        />
        <Button variant="secondary" size="icon" className="bg-white text-pink-500 hover:bg-gray-100 hover:text-blue-500">
          <Settings className="h-6 w-6" />
        </Button>
      </nav>

      {/* Matches Section */}
      <div className="bg-white p-4">
        <h2 className="mb-4 text-lg font-semibold text-white">Your Matches</h2>
        <div className="flex space-x-4 overflow-x-auto pb-4">
          {matches.map((match) => (
            <Link href={`/chat/${match.id}`} key={match.id}>
              <motion.div
                className="flex flex-col items-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="relative">
                  <Image
                    src={match.photo}
                    alt={match.name}
                    width={60}
                    height={60}
                    className="rounded-full object-cover"
                  />
                  <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${match.online ? 'bg-green-500' : 'bg-gray-400'}`} />
                </div>
                <p className="mt-1 text-sm font-medium text-gray-800">{match.name}</p>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>

      {/* Messages Section */}
      <div className="flex-1 overflow-y-auto">
        <h2 className="p-4 text-lg font-semibold text-gray-800">Messages</h2>
        {messages.map((message) => (
          <Link href={`/chat/${message.id}`} key={message.id}>
            <motion.div
              className="flex items-center border-b border-gray-200 bg-white p-4"
              whileHover={{ backgroundColor: '#f3f4f6' }}
            >
              <Image
                src={message.photo}
                alt={message.name}
                width={50}
                height={50}
                className="rounded-full object-cover"
              />
              <div className="ml-4 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-gray-800">{message.name}</h3>
                  {message.unread && (
                    <Moon className="h-4 w-4 text-blue-500" />
                  )}
                </div>
                <p className="text-sm text-gray-700">{message.lastMessage}</p>
              </div>
            </motion.div>
          </Link>
        ))}
      </div>
    </div>
  )
}

export default MatchesAndMessages

