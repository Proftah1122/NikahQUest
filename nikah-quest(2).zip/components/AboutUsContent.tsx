import { motion } from 'framer-motion'
import { Heart, Shield, Users, Star } from 'lucide-react'

export function AboutUsContent() {
  return (
    <div className="container mx-auto px-4 py-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        About NikahQuest
      </motion.h1>
      
      <motion.p 
        className="text-lg text-center mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Welcome to NikahQuest – a unique and faith-inspired platform dedicated to helping Muslim singles connect, bond, and build meaningful relationships rooted in Islamic principles.
      </motion.p>

      <motion.section 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <h2 className="text-2xl font-semibold mb-4">Who We Are</h2>
        <p className="mb-4">
          We are more than a dating app; we are a community. At NikahQuest, we are committed to fostering halal connections between individuals who share common values, goals, and a deep respect for their faith. Our platform is designed to encourage transparency, mutual respect, and meaningful communication, paving the way for lifelong companionship.
        </p>
        <p>
          Our team consists of passionate Muslims who believe in the beauty of marriage as ordained by Allah. We aim to offer a safe, inclusive, and user-friendly environment for all users while staying true to Islamic teachings.
        </p>
      </motion.section>

      <motion.section 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <h2 className="text-2xl font-semibold mb-4">What Makes Us Unique?</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="flex items-start">
            <Heart className="mr-4 text-pink-500" />
            <div>
              <h3 className="font-semibold mb-2">Faith-Centric Approach</h3>
              <p>Every feature on our platform is developed with a focus on preserving Islamic values. From our halal matching process to the carefully curated content, we prioritize your spiritual well-being.</p>
            </div>
          </div>
          <div className="flex items-start">
            <Shield className="mr-4 text-blue-500" />
            <div>
              <h3 className="font-semibold mb-2">Respect for Privacy</h3>
              <p>Your privacy and dignity are paramount to us. Our app ensures your personal information is protected, and interactions are conducted respectfully.</p>
            </div>
          </div>
          <div className="flex items-start">
            <Star className="mr-4 text-yellow-500" />
            <div>
              <h3 className="font-semibold mb-2">Guided Experience</h3>
              <p>With Quranic verses and Hadiths beautifully displayed throughout the platform, we aim to remind users of the spiritual significance of marriage and inspire hope and patience in their search.</p>
            </div>
          </div>
          <div className="flex items-start">
            <Users className="mr-4 text-green-500" />
            <div>
              <h3 className="font-semibold mb-2">Tailored Features</h3>
              <p>Our platform combines modern technology with Islamic traditions, offering unique features such as personalized bios, match notifications with celebratory effects, and easy navigation to explore compatibility.</p>
            </div>
          </div>
        </div>
      </motion.section>

      <motion.section 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      >
        <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
        <p>
          To create a platform where Muslims can discover meaningful relationships while adhering to Islamic principles of modesty, respect, and mutual understanding. We strive to inspire hope, comfort, and confidence in every heart seeking companionship.
        </p>
      </motion.section>

      <motion.section 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        <h2 className="text-2xl font-semibold mb-4">Our Vision</h2>
        <p>
          To be the leading global Muslim matchmaking platform, connecting hearts and building homes based on the values of love, mercy, and tranquility as enshrined in the Quran and Sunnah.
        </p>
      </motion.section>

      <motion.section 
        className="text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1.2 }}
      >
        <h2 className="text-2xl font-semibold mb-4">Join Us Today</h2>
        <p className="mb-4">
          Whether you're seeking companionship, a life partner, or a place to meet like-minded individuals, NikahQuest is here to guide you every step of the way. Together, let's build relationships that are pleasing to Allah and fulfilling for you.
        </p>
        <p className="mb-4">
          If you have questions or need support, please feel free to reach out to us. We are always here to assist you.
        </p>
        <p className="text-xl font-semibold">
          Discover love. Connect with faith. Join NikahQuest today!
        </p>
      </motion.section>
    </div>
  )
}

