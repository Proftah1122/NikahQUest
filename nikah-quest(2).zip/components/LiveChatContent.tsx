'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Send } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export function LiveChatContent() {
  const [messages, setMessages] = useState<{ text: string; sender: 'user' | 'support' }[]>([
    { text: "Hello! How can I assist you today?", sender: 'support' }
  ])
  const [inputMessage, setInputMessage] = useState('')

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputMessage.trim()) {
      setMessages([...messages, { text: inputMessage, sender: 'user' }])
      setInputMessage('')
      // Simulate a response from support (in a real app, this would be handled by a backend)
      setTimeout(() => {
        setMessages(prev => [...prev, { text: "Thank you for your message. A support representative will be with you shortly.", sender: 'support' }])
      }, 1000)
    }
  }

  return (
    <div className="container mx-auto px-4 py-16 h-screen flex flex-col">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Live Chat Support
      </motion.h1>
      
      <div className="flex-grow overflow-auto mb-4 bg-gray-800 rounded-lg p-4">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            className={`mb-2 ${message.sender === 'user' ? 'text-right' : 'text-left'}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className={`inline-block p-2 rounded-lg ${message.sender === 'user' ? 'bg-blue-500' : 'bg-gray-600'}`}>
              {message.text}
            </span>
          </motion.div>
        ))}
      </div>

      <form onSubmit={handleSendMessage} className="flex gap-2">
        <Input
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder="Type your message here..."
          className="flex-grow"
        />
        <Button type="submit" className="bg-gradient-to-r from-pink-500 to-blue-500">
          <Send className="mr-2" />
          Send
        </Button>
      </form>
    </div>
  )
}

