'use client'

import { useState, useRef, useEffect } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { ArrowLeft, Send, Phone, Video } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Link from 'next/link'
import { BackButton } from './BackButton'

interface Message {
  id: number
  sender: 'user' | 'match'
  content: string
  timestamp: Date
}

interface ChatScreenProps {
  matchId: string
  matchName: string
  matchPhoto: string
}

const ChatScreen: React.FC<ChatScreenProps> = ({ matchId, matchName, matchPhoto }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, sender: 'match', content: 'Assalamu alaikum! How are you?', timestamp: new Date(Date.now() - 1000 * 60 * 5) },
    { id: 2, sender: 'user', content: 'Wa alaikum assalam! I\'m doing well, alhamdulillah. How about you?', timestamp: new Date(Date.now() - 1000 * 60 * 4) },
    { id: 3, sender: 'match', content: 'Alhamdulillah, I\'m good too. I was wondering if you\'d like to discuss our views on marriage and family?', timestamp: new Date(Date.now() - 1000 * 60 * 3) },
  ])
  const [newMessage, setNewMessage] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(scrollToBottom, [messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (newMessage.trim()) {
      const newMsg: Message = {
        id: messages.length + 1,
        sender: 'user',
        content: newMessage.trim(),
        timestamp: new Date(),
      }
      setMessages([...messages, newMsg])
      setNewMessage('')
    }
  }

  return (
    <div className="flex h-screen flex-col bg-gray-100">
      <BackButton />
      {/* Chat Header */}
      <div className="flex items-center justify-between bg-white p-4 shadow-md">
        <div className="flex items-center">
          <Link href="/matches">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <Link href={`/profile/${matchId}`} className="flex items-center">
            <div className="relative">
              <Image
                src={matchPhoto}
                alt={matchName}
                width={40}
                height={40}
                className="rounded-full"
              />
              <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex h-3 w-3 rounded-full bg-green-500"></span>
              </span>
            </div>
            <span className="ml-2 text-lg font-semibold">{matchName}</span>
          </Link>
        </div>
        <div className="flex space-x-2">
          <Button variant="ghost" size="icon">
            <Phone className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {messages.map((message) => (
          <motion.div
            key={message.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mb-4 flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] rounded-lg p-3 ${
                message.sender === 'user'
                  ? 'bg-gradient-to-r from-pink-500 to-blue-500 text-white'
                  : 'bg-white text-gray-800'
              }`}
            >
              <p>{message.content}</p>
              <p className="mt-1 text-right text-xs text-gray-300">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </motion.div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form onSubmit={handleSendMessage} className="bg-white p-4">
        <div className="flex items-center space-x-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 bg-gray-100 text-gray-800 placeholder-gray-500 border-gray-300 focus:border-pink-500 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
          />
          <Button type="submit" size="icon" className="bg-gradient-to-r from-pink-500 to-blue-500">
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </form>
    </div>
  )
}

export default ChatScreen

