import Link from 'next/link'
import { Home } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function HomeButton() {
  return (
    <Link href="/home">
      <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50">
        <Home className="h-6 w-6" />
      </Button>
    </Link>
  )
}

