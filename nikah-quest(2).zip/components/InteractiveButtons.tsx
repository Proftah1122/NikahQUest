import { Heart, Star, X } from 'lucide-react'
import { motion } from 'framer-motion'

interface InteractiveButtonsProps {
  onLike: () => void
  onSuperLike: () => void
  onPass: () => void
}

export function InteractiveButtons({ onLike, onSuperLike, onPass }: InteractiveButtonsProps) {
  return (
    <div className="mt-6 flex justify-center space-x-4">
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="rounded-full bg-red-500 p-4 text-white shadow-lg"
        onClick={onPass}
      >
        <X size={24} />
      </motion.button>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="rounded-full bg-blue-500 p-4 text-white shadow-lg"
        onClick={onSuperLike}
      >
        <Star size={24} />
      </motion.button>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="rounded-full bg-green-500 p-4 text-white shadow-lg"
        onClick={onLike}
      >
        <Heart size={24} />
      </motion.button>
    </div>
  )
}

