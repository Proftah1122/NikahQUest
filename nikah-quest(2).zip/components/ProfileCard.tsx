import Image from 'next/image'
import { motion } from 'framer-motion'

interface ProfileCardProps {
  name: string
  age: number
  bio: string
  photo: string
}

export function ProfileCard({ name, age, bio, photo }: ProfileCardProps) {
  return (
    <motion.div
      className="relative h-[500px] w-full max-w-[350px] overflow-hidden rounded-2xl bg-gray-800 shadow-xl"
      whileHover={{ scale: 1.03 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <Image
        src={photo}
        alt={`${name}'s profile picture`}
        layout="fill"
        objectFit="cover"
        className="absolute inset-0"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
        <h2 className="text-3xl font-bold">{name}, {age}</h2>
        <p className="mt-2 text-sm">{bio}</p>
      </div>
    </motion.div>
  )
}

