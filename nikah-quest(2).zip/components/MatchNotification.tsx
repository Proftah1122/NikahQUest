import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { Button } from '@/components/ui/button'

interface Profile {
  name: string;
  photo: string;
  gender: 'male' | 'female';
  id: number; // Added id property to Profile
}

interface MatchNotificationProps {
  user1: Profile
  user2: Profile
  onStartChat: (matchId: number) => void
  onContinueExploring: () => void
}

const MatchNotification: React.FC<MatchNotificationProps> = ({
  user1,
  user2,
  onStartChat,
  onContinueExploring,
}) => {
  const [showConfetti, setShowConfetti] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 5000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="fixed inset-0 z-50 flex items-center justify-center"
    >
      <div className="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" />
      <div className="relative rounded-3xl bg-white p-8 text-center shadow-2xl">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6 flex justify-center space-x-4"
        >
          {[user1, user2].map((user, index) => (
            <div key={index} className="relative">
              <div className="absolute inset-0 animate-pulse rounded-full bg-gradient-to-r from-pink-400 to-blue-500" />
              <Image
                src={user.photo}
                alt={user.name}
                width={120}
                height={120}
                className="relative z-10 rounded-full border-4 border-white object-cover"
              />
            </div>
          ))}
        </motion.div>
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-6 text-4xl font-bold"
        >
          <span className="bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">
            It's a Match!
          </span>
        </motion.h2>
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="space-y-4"
        >
          <Button
            onClick={() => onStartChat(user2.id)}
            className="w-full bg-gradient-to-r from-pink-500 to-blue-500 text-white transition-all hover:from-pink-600 hover:to-blue-600"
          >
            Start Chat
          </Button>
          <Button
            onClick={onContinueExploring}
            variant="outline"
            className="w-full"
          >
            Continue Exploring
          </Button>
        </motion.div>
      </div>
      <AnimatePresence>
        {showConfetti && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none absolute inset-0"
          >
            <div className="absolute inset-0 overflow-hidden">
              {[...Array(50)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute h-4 w-4 rounded-full bg-pink-500 opacity-75"
                  initial={{
                    x: Math.random() * window.innerWidth,
                    y: -20,
                    scale: 0,
                  }}
                  animate={{
                    y: window.innerHeight + 20,
                    scale: Math.random() * 0.5 + 0.5,
                  }}
                  transition={{
                    duration: Math.random() * 2 + 2,
                    repeat: Infinity,
                    repeatType: 'loop',
                  }}
                />
              ))}
              {[...Array(50)].map((_, i) => (
                <motion.div
                  key={i + 50}
                  className="absolute h-4 w-4 rounded-full bg-blue-500 opacity-75"
                  initial={{
                    x: Math.random() * window.innerWidth,
                    y: -20,
                    scale: 0,
                  }}
                  animate={{
                    y: window.innerHeight + 20,
                    scale: Math.random() * 0.5 + 0.5,
                  }}
                  transition={{
                    duration: Math.random() * 2 + 2,
                    repeat: Infinity,
                    repeatType: 'loop',
                  }}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export default MatchNotification

