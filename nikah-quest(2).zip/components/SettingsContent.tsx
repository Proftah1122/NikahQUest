'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { User, Lock, Bell, Sliders, HelpCircle, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { useRouter } from 'next/navigation'

export function SettingsContent() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState('account')

  const handleLogout = () => {
    // Implement logout logic here
    console.log('Logging out...')
    router.push('/signin')
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'account':
        return <AccountSettings />
      case 'privacy':
        return <PrivacySettings />
      case 'notifications':
        return <NotificationPreferences />
      case 'preferences':
        return <AppPreferences />
      case 'help':
        return <HelpSupport />
      default:
        return null
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.h1 
        className="text-3xl font-bold mb-8 text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Settings
      </motion.h1>

      <div className="flex flex-col md:flex-row gap-8">
        <motion.div 
          className="w-full md:w-1/4"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <nav className="space-y-2">
            <Button
              variant={activeTab === 'account' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActiveTab('account')}
            >
              <User className="mr-2 h-4 w-4" />
              Account Settings
            </Button>
            <Button
              variant={activeTab === 'privacy' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActiveTab('privacy')}
            >
              <Lock className="mr-2 h-4 w-4" />
              Privacy Settings
            </Button>
            <Button
              variant={activeTab === 'notifications' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActiveTab('notifications')}
            >
              <Bell className="mr-2 h-4 w-4" />
              Notification Preferences
            </Button>
            <Button
              variant={activeTab === 'preferences' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActiveTab('preferences')}
            >
              <Sliders className="mr-2 h-4 w-4" />
              App Preferences
            </Button>
            <Button
              variant={activeTab === 'help' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActiveTab('help')}
            >
              <HelpCircle className="mr-2 h-4 w-4" />
              Help & Support
            </Button>
            <Button
              variant="destructive"
              className="w-full justify-start"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </nav>
        </motion.div>

        <motion.div 
          className="w-full md:w-3/4"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          {renderTabContent()}
        </motion.div>
      </div>
    </div>
  )
}

function AccountSettings() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-4">Account Settings</h2>
      <div className="space-y-4">
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" placeholder="your.email@example.com" />
        </div>
        <div>
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" placeholder="••••••••" />
        </div>
        <div>
          <Label htmlFor="phone">Phone Number</Label>
          <Input id="phone" type="tel" placeholder="+1234567890" />
        </div>
        <Button>Update Account Information</Button>
      </div>
    </div>
  )
}

function PrivacySettings() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-4">Privacy Settings</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="profile-visibility">Profile Visibility</Label>
          <Switch id="profile-visibility" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="location-sharing">Location Sharing</Label>
          <Switch id="location-sharing" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="activity-status">Show Activity Status</Label>
          <Switch id="activity-status" />
        </div>
        <div>
          <Label htmlFor="blocked-users">Blocked Users</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Manage blocked users" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="view">View Blocked Users</SelectItem>
              <SelectItem value="add">Add User to Block List</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  )
}

function NotificationPreferences() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-4">Notification Preferences</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="new-matches">New Matches</Label>
          <Switch id="new-matches" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="messages">Messages</Label>
          <Switch id="messages" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="app-updates">App Updates</Label>
          <Switch id="app-updates" />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="email-notifications">Email Notifications</Label>
          <Switch id="email-notifications" />
        </div>
      </div>
    </div>
  )
}

function AppPreferences() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-4">App Preferences</h2>
      <div className="space-y-4">
        <div>
          <Label htmlFor="language">Language</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="ar">Arabic</SelectItem>
              <SelectItem value="ur">Urdu</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="theme">Theme</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Distance Unit</Label>
          <div className="flex items-center space-x-2">
            <Button variant="outline">Kilometers</Button>
            <Button variant="outline">Miles</Button>
          </div>
        </div>
        <div>
          <Label>Age Range Preference</Label>
          <Slider
            defaultValue={[18, 50]}
            max={80}
            min={18}
            step={1}
          />
          <div className="flex justify-between mt-2">
            <span>18</span>
            <span>80</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function HelpSupport() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-4">Help & Support</h2>
      <div className="space-y-4">
        <Button variant="outline" className="w-full justify-start">
          FAQs
        </Button>
        <Button variant="outline" className="w-full justify-start">
          Contact Support
        </Button>
        <Button variant="outline" className="w-full justify-start">
          Report a Problem
        </Button>
        <Button variant="outline" className="w-full justify-start">
          Terms of Service
        </Button>
        <Button variant="outline" className="w-full justify-start">
          Privacy Policy
        </Button>
      </div>
    </div>
  )
}

