import { useState } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'

interface EnlargedImageProps {
  src: string
  alt: string
  onClose: () => void
}

export function EnlargedImage({ src, alt, onClose }: EnlargedImageProps) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          exit={{ scale: 0.8 }}
          className="relative max-h-full max-w-full overflow-hidden rounded-lg"
          onClick={(e) => e.stopPropagation()}
        >
          <Image
            src={src}
            alt={alt}
            width={800}
            height={800}
            objectFit="contain"
            className="rounded-lg"
          />
          <button
            onClick={onClose}
            className="absolute right-2 top-2 rounded-full bg-white p-1 text-gray-800 shadow-md transition-colors hover:bg-gray-200"
          >
            <X size={24} />
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

