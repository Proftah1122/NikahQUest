import { AlertTriangle, Lock, Shield, Eye, UserPlus } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export function DisclaimerAndTips() {
  return (
    <Card className="bg-gray-800 text-white">
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertTriangle className="mr-2 h-5 w-5 text-yellow-400" />
          Important Security Information
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="mb-4">
          Your safety and privacy are our top priorities. Please read the following security tips carefully:
        </p>
        <ul className="space-y-2">
          <li className="flex items-start">
            <Lock className="mr-2 h-5 w-5 text-blue-400 mt-0.5" />
            <span>Use a strong, unique password for your NikahQuest account. Never share it with anyone.</span>
          </li>
          <li className="flex items-start">
            <Shield className="mr-2 h-5 w-5 text-green-400 mt-0.5" />
            <span>Enable two-factor authentication for an extra layer of security.</span>
          </li>
          <li className="flex items-start">
            <Eye className="mr-2 h-5 w-5 text-purple-400 mt-0.5" />
            <span>Be cautious about sharing personal information. Get to know someone before revealing sensitive details.</span>
          </li>
          <li className="flex items-start">
            <UserPlus className="mr-2 h-5 w-5 text-pink-400 mt-0.5" />
            <span>Report any suspicious behavior or profiles to our support team immediately.</span>
          </li>
        </ul>
        <p className="mt-4 text-sm text-gray-400">
          By using NikahQuest, you agree to our Terms of Service and Privacy Policy. We are committed to protecting your personal information and providing a safe environment for finding your life partner.
        </p>
      </CardContent>
    </Card>
  )
}

