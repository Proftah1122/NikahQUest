'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import CreateAccount from './steps/create-account'
import ProfileDetails from './steps/profile-details'
import AddPhotos from './steps/add-photos'
import PersonalPreferences from './steps/personal-preferences'
import { LivenessDetection } from './LivenessDetection'
import { DisclaimerAndTips } from './DisclaimerAndTips'
import { SignUpFormData } from '@/lib/types/auth-types'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import Calendar from '@/components/ui/calendar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { BackButton } from '../BackButton'
import { Button } from '@/components/ui/button'

const INITIAL_DATA: SignUpFormData = {
  name: '',
  email: '',
  password: '',
  phoneNumber: '',
  gender: 'male',
  preferredMatch: 'female',
  dateOfBirth: null,
  sect: '',
  prayerHabits: '',
  halalPreferences: '',
  photos: [],
  ageRange: [18, 50],
  locationRadius: 50,
  interests: [],
  maritalStatus: '',
  acceptableMaritalStatuses: [],
  hasChildren: false,
  numberOfChildren: 0,
  maxAcceptableChildren: 0,
  polygamyPreference: 'closed',
  isPolygamyDealBreaker: false,
  livenessVerified: false,
}

export default function SignUpForm() {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState(INITIAL_DATA)
  const [isComplete, setIsComplete] = useState(false)
  const router = useRouter()

  const updateFields = (fields: Partial<SignUpFormData>) => {
    setFormData(prev => ({ ...prev, ...fields }))
  }

  const nextStep = () => {
    setCurrentStep(c => c + 1)
  }

  const prevStep = () => {
    setCurrentStep(c => c - 1)
  }

  const steps = [
    { component: CreateAccount, title: 'Create Account' },
    { component: ProfileDetails, title: 'Profile Details' },
    { component: AddPhotos, title: 'Add Photos' },
    { component: PersonalPreferences, title: 'Personal Preferences' },
    { component: LivenessDetection, title: 'Verify Identity' },
  ]

  const CurrentStepComponent = steps[currentStep].component

  const handleLivenessComplete = () => {
    // Here you would typically submit the form data to your backend
    console.log('Sign-up complete:', formData)
    setIsComplete(true)
  }

  const handleReturnToSignUp = () => {
    router.push('/signup')
  }

  return (
    <div className="min-h-screen bg-black px-4 py-8 dark">
      <BackButton />
      <div className="mx-auto max-w-2xl rounded-xl bg-gray-900/50 p-6 backdrop-blur-lg">
        {!isComplete ? (
          <>
            {/* Progress Bar */}
            <div className="mb-8">
              <div className="mb-4 flex justify-between">
                {steps.map((step, index) => (
                  <div
                    key={step.title}
                    className={`flex flex-col items-center ${
                      index <= currentStep ? 'text-[#FF1493]' : 'text-gray-500'
                    }`}
                  >
                    <div
                      className={`mb-2 h-8 w-8 rounded-full ${
                        index <= currentStep ? 'bg-[#FF1493]' : 'bg-gray-700'
                      } flex items-center justify-center text-white`}
                    >
                      {index + 1}
                    </div>
                    <span className="hidden text-sm md:block">{step.title}</span>
                  </div>
                ))}
              </div>
              <div className="relative h-2 rounded-full bg-gray-700">
                <motion.div
                  className="absolute left-0 top-0 h-full rounded-full bg-gradient-to-r from-[#FF1493] to-[#1E90FF]"
                  initial={{ width: '0%' }}
                  animate={{
                    width: `${((currentStep + 1) / steps.length) * 100}%`
                  }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Form Steps */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                {currentStep < steps.length - 1 ? (
                  <CurrentStepComponent
                    data={formData}
                    updateFields={updateFields}
                    onNext={nextStep}
                    onBack={currentStep > 0 ? prevStep : undefined}
                  />
                ) : (
                  <LivenessDetection onComplete={handleLivenessComplete} />
                )}
              </motion.div>
            </AnimatePresence>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Sign Up Complete!</h2>
              <p className="text-gray-300 mb-6">Thank you for joining NikahQuest. Your account has been created successfully.</p>
            </div>
            
            <DisclaimerAndTips />
            
            <Button
              onClick={handleReturnToSignUp}
              className="w-full bg-gradient-to-r from-[#FF1493] to-[#1E90FF] text-white"
            >
              Return to Sign Up Page
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  )
}

