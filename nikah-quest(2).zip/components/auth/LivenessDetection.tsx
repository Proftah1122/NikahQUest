'use client'

import { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Camera, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'

const livenessChecks = [
  { instruction: 'Turn your head left', action: 'HEAD_LEFT' },
  { instruction: 'Turn your head right', action: 'HEAD_RIGHT' },
  { instruction: 'Blink twice slowly', action: 'BLINK' },
  { instruction: 'Smile', action: 'SMILE' },
  { instruction: 'Frown', action: 'FROWN' },
  { instruction: 'Move your ID closer to the camera', action: 'ID_CLOSER' },
  { instruction: 'Move your ID further from the camera', action: 'ID_FURTHER' },
]

export function LivenessDetection({ onComplete }: { onComplete: () => void }) {
  const [cameraPermission, setCameraPermission] = useState<boolean | null>(null)
  const [currentCheck, setCurrentCheck] = useState(0)
  const [checksPassed, setChecksPassed] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    requestCameraPermission()
  }, [])

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setCameraPermission(true)
    } catch (err) {
      console.error('Error accessing camera:', err)
      setCameraPermission(false)
    }
  }

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d')
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height)
        return canvasRef.current.toDataURL('image/jpeg')
      }
    }
    return null
  }

  const validateLiveness = async () => {
    const frame = captureFrame()
    if (frame) {
      // In a real implementation, you would send this frame to your AI service for analysis
      // For this example, we'll simulate a successful check after a short delay
      await new Promise(resolve => setTimeout(resolve, 1000))
      setChecksPassed(prev => prev + 1)
      if (checksPassed + 1 === livenessChecks.length) {
        onComplete()
      } else {
        setCurrentCheck(prev => (prev + 1) % livenessChecks.length)
      }
    }
  }

  if (cameraPermission === null) {
    return <div>Requesting camera permission...</div>
  }

  if (cameraPermission === false) {
    return (
      <div className="text-center">
        <p className="mb-4">Camera access is required for liveness detection.</p>
        <Button onClick={requestCameraPermission}>
          <Camera className="mr-2 h-4 w-4" />
          Grant Camera Access
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="relative aspect-video">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover rounded-lg"
        />
        <canvas ref={canvasRef} className="hidden" width="640" height="480" />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white text-xl font-bold"
        >
          {livenessChecks[currentCheck].instruction}
        </motion.div>
      </div>
      <div className="flex justify-between items-center">
        <p>Checks passed: {checksPassed}/{livenessChecks.length}</p>
        <Button onClick={validateLiveness}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Validate
        </Button>
      </div>
    </div>
  )
}

