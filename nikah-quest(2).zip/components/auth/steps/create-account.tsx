'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { StepProps } from '@/lib/types/auth-types'
import { FaGoogle, FaApple } from 'react-icons/fa'

export default function CreateAccount({ data, updateFields, onNext }: StepProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateFields = () => {
    const newErrors: Record<string, string> = {}

    if (!data.name) newErrors.name = 'Name is required'
    if (!data.email) newErrors.email = 'Email is required'
    if (!data.password) newErrors.password = 'Password is required'
    if (!data.phoneNumber) newErrors.phoneNumber = 'Phone number is required'

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateFields()) {
      onNext()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Full Name</Label>
          <Input
            id="name"
            type="text"
            placeholder="Enter your full name"
            value={data.name}
            onChange={e => updateFields({ name: e.target.value })}
            className={errors.name ? 'border-red-500' : ''}
          />
          {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name}</p>}
        </div>

        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            placeholder="Enter your email address"
            value={data.email}
            onChange={e => updateFields({ email: e.target.value })}
            className={errors.email ? 'border-red-500' : ''}
          />
          {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email}</p>}
        </div>

        <div>
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            placeholder="Create a strong password"
            value={data.password}
            onChange={e => updateFields({ password: e.target.value })}
            className={errors.password ? 'border-red-500' : ''}
          />
          {errors.password && (
            <p className="mt-1 text-sm text-red-500">{errors.password}</p>
          )}
        </div>

        <div>
          <Label htmlFor="phoneNumber">Phone Number</Label>
          <Input
            id="phoneNumber"
            type="tel"
            placeholder="Enter your phone number"
            value={data.phoneNumber}
            onChange={e => updateFields({ phoneNumber: e.target.value })}
            className={errors.phoneNumber ? 'border-red-500' : ''}
          />
          {errors.phoneNumber && (
            <p className="mt-1 text-sm text-red-500">{errors.phoneNumber}</p>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <Button
          type="button"
          variant="outline"
          className="w-full flex items-center justify-center space-x-2"
          onClick={() => {
            // Implement Google sign-in
          }}
        >
          <FaGoogle className="h-5 w-5 text-red-500" />
          <span>Continue with Google</span>
        </Button>

        <Button
          type="button"
          variant="outline"
          className="w-full flex items-center justify-center space-x-2"
          onClick={() => {
            // Implement Apple sign-in
          }}
        >
          <FaApple className="h-5 w-5" />
          <span>Continue with Apple</span>
        </Button>
      </div>

      <Button type="submit" className="w-full bg-gradient-to-r from-[#FF1493] to-[#1E90FF]">
        Continue
      </Button>
    </form>
  )
}

