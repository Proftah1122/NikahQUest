'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { StepProps } from '@/lib/types/auth-types'
import { Upload } from 'lucide-react'
import Image from 'next/image'

export default function AddPhotos({ data, updateFields, onNext, onBack }: StepProps) {
  const [errors, setErrors] = useState<string[]>([])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // Convert FileList to array and get URLs
    const newPhotos = Array.from(files).map(file => URL.createObjectURL(file))
    updateFields({ photos: [...data.photos, ...newPhotos] })
  }

  const removePhoto = (index: number) => {
    const newPhotos = data.photos.filter((_, i) => i !== index)
    updateFields({ photos: newPhotos })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors = []
    if (data.photos.length === 0) {
      newErrors.push('Please upload at least one photo')
    }
    if (data.photos.length > 6) {
      newErrors.push('Maximum 6 photos allowed')
    }
    setErrors(newErrors)

    if (newErrors.length === 0) {
      onNext()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div className="text-center">
          <h3 className="text-lg font-medium">Add Your Photos</h3>
          <p className="text-sm text-gray-400">
            Upload up to 6 photos. First photo will be your profile picture.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <div
              key={index}
              className="relative aspect-square rounded-lg border-2 border-dashed border-gray-600"
            >
              {data.photos[index] ? (
                <div className="relative h-full w-full">
                  <Image
                    src={data.photos[index]}
                    alt={`Photo ${index + 1}`}
                    fill
                    className="rounded-lg object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => removePhoto(index)}
                    className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 text-white hover:bg-red-600"
                  >
                    ×
                  </button>
                </div>
              ) : (
                <label className="flex h-full cursor-pointer flex-col items-center justify-center">
                  <Upload className="h-8 w-8 text-gray-400" />
                  <span className="mt-2 text-sm text-gray-400">Upload</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              )}
            </div>
          ))}
        </div>

        {errors.map((error, index) => (
          <p key={index} className="text-center text-sm text-red-500">
            {error}
          </p>
        ))}
      </div>

      <div className="flex justify-between space-x-4">
        <Button type="button" variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button
          type="submit"
          className="bg-gradient-to-r from-[#FF1493] to-[#1E90FF]"
        >
          Continue
        </Button>
      </div>
    </form>
  )
}

