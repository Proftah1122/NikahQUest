'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { StepProps } from '@/lib/types/auth-types'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'

const INTERESTS = [
  'Reading',
  'Traveling',
  'Cooking',
  'Sports',
  'Art',
  'Music',
  'Photography',
  'Writing',
  'Technology',
  'Nature',
  'Fitness',
  'Movies',
]

export default function PersonalPreferences({
  data,
  updateFields,
  onNext,
  onBack,
}: StepProps) {
  const [newInterest, setNewInterest] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleAddInterest = () => {
    if (newInterest.trim() && !data.interests.includes(newInterest.trim())) {
      updateFields({ interests: [...data.interests, newInterest.trim()] })
      setNewInterest('')
    }
  }

  const handleRemoveInterest = (interest: string) => {
    updateFields({
      interests: data.interests.filter(i => i !== interest),
    })
  }

  const validateFields = () => {
    const newErrors: Record<string, string> = {}

    if (data.interests.length === 0) {
      newErrors.interests = 'Please select at least one interest'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (validateFields()) {
      // Here you would typically submit the complete form data
      console.log('Form submitted:', data)
      onNext()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-6">
        <div>
          <Label>Age Range</Label>
          <div className="mt-2">
            <Slider
              value={[data.ageRange[0], data.ageRange[1]]}
              min={18}
              max={80}
              step={1}
              onValueChange={([min, max]) =>
                updateFields({ ageRange: [min, max] })
              }
            />
            <div className="mt-2 flex justify-between text-sm">
              <span>{data.ageRange[0]} years</span>
              <span>{data.ageRange[1]} years</span>
            </div>
          </div>
        </div>

        <div>
          <Label>Location Radius</Label>
          <div className="mt-2">
            <Slider
              value={[data.locationRadius]}
              min={5}
              max={500}
              step={5}
              onValueChange={([value]) =>
                updateFields({ locationRadius: value })
              }
            />
            <div className="mt-2 text-sm">{data.locationRadius} km</div>
          </div>
        </div>

        <div>
          <Label>Interests</Label>
          <div className="mt-2 space-y-4">
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map(interest => (
                <Badge
                  key={interest}
                  variant={
                    data.interests.includes(interest) ? 'default' : 'outline'
                  }
                  className="cursor-pointer"
                  onClick={() => {
                    if (data.interests.includes(interest)) {
                      handleRemoveInterest(interest)
                    } else {
                      updateFields({
                        interests: [...data.interests, interest],
                      })
                    }
                  }}
                >
                  {interest}
                </Badge>
              ))}
            </div>

            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Add custom interest"
                value={newInterest}
                onChange={e => setNewInterest(e.target.value)}
                onKeyPress={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    handleAddInterest()
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleAddInterest}
              >
                Add
              </Button>
            </div>

            {errors.interests && (
              <p className="text-sm text-red-500">{errors.interests}</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-between space-x-4">
        <Button type="button" variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button
          type="submit"
          className="bg-gradient-to-r from-[#FF1493] to-[#1E90FF]"
        >
          Complete Sign Up
        </Button>
      </div>
    </form>
  )
}

