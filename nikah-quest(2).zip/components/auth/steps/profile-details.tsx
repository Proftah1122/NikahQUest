'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { StepProps } from '@/lib/types/auth-types'
import { Calendar } from '@/components/ui/calendar'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { format } from 'date-fns'
import { CalendarIcon } from 'lucide-react'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'

export default function ProfileDetails({
  data,
  updateFields,
  onNext,
  onBack,
}: StepProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateFields = () => {
    const newErrors: Record<string, string> = {}

    if (!data.gender) newErrors.gender = 'Gender is required'
    if (!data.preferredMatch) newErrors.preferredMatch = 'Preferred match is required'
    if (!data.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required'
    if (!data.sect) newErrors.sect = 'Sect is required'
    if (!data.prayerHabits) newErrors.prayerHabits = 'Prayer habits are required'
    if (!data.halalPreferences)
      newErrors.halalPreferences = 'Halal preferences are required'
    if (!data.maritalStatus) newErrors.maritalStatus = 'Marital status is required'
    if (data.acceptableMaritalStatuses.length === 0)
      newErrors.acceptableMaritalStatuses = 'Please select at least one acceptable marital status'
    if (data.hasChildren && data.numberOfChildren === 0)
      newErrors.numberOfChildren = 'Please specify the number of children'
    if (!data.polygamyPreference)
      newErrors.polygamyPreference = 'Polygamy preference is required'

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateFields()) {
      onNext()
    }
  }

  const maritalStatusOptions = ['Never Married', 'Divorced', 'Widowed', 'Separated']

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <Label htmlFor="gender">Gender</Label>
          <Select
            value={data.gender}
            onValueChange={value => updateFields({ gender: value as 'male' | 'female' })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
          {errors.gender && <p className="mt-1 text-sm text-red-500">{errors.gender}</p>}
        </div>

        <div>
          <Label htmlFor="preferredMatch">Preferred Match</Label>
          <Select
            value={data.preferredMatch}
            onValueChange={value =>
              updateFields({ preferredMatch: value as 'male' | 'female' })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select preferred match" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
          {errors.preferredMatch && (
            <p className="mt-1 text-sm text-red-500">{errors.preferredMatch}</p>
          )}
        </div>

        <div className="col-span-2">
          <Label>Date of Birth</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={`w-full justify-start text-left font-normal ${
                  !data.dateOfBirth && 'text-muted-foreground'
                }`}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {data.dateOfBirth ? (
                  format(data.dateOfBirth, 'PPP')
                ) : (
                  <span>Pick your date of birth</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={data.dateOfBirth || undefined}
                onSelect={(date) => updateFields({ dateOfBirth: date })}
                disabled={{ after: new Date() }}
                initialFocus
                captionLayout="dropdown-buttons"
                fromYear={1940}
                toYear={2006}
              />
            </PopoverContent>
          </Popover>
          {errors.dateOfBirth && (
            <p className="mt-1 text-sm text-red-500">{errors.dateOfBirth}</p>
          )}
        </div>

        <div>
          <Label htmlFor="sect">Sect</Label>
          <Select value={data.sect} onValueChange={value => updateFields({ sect: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select sect" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sunni">Sunni</SelectItem>
              <SelectItem value="shia">Shia</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          {errors.sect && <p className="mt-1 text-sm text-red-500">{errors.sect}</p>}
        </div>

        <div>
          <Label htmlFor="prayerHabits">Prayer Habits</Label>
          <Select
            value={data.prayerHabits}
            onValueChange={value => updateFields({ prayerHabits: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select prayer habits" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="always">Always Pray</SelectItem>
              <SelectItem value="usually">Usually Pray</SelectItem>
              <SelectItem value="sometimes">Sometimes Pray</SelectItem>
              <SelectItem value="rarely">Rarely Pray</SelectItem>
            </SelectContent>
          </Select>
          {errors.prayerHabits && (
            <p className="mt-1 text-sm text-red-500">{errors.prayerHabits}</p>
          )}
        </div>

        <div>
          <Label htmlFor="halalPreferences">Halal Preferences</Label>
          <Select
            value={data.halalPreferences}
            onValueChange={value => updateFields({ halalPreferences: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select halal preferences" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="strict">Strictly Halal</SelectItem>
              <SelectItem value="preferred">Halal Preferred</SelectItem>
              <SelectItem value="sometimes">Sometimes Halal</SelectItem>
            </SelectContent>
          </Select>
          {errors.halalPreferences && (
            <p className="mt-1 text-sm text-red-500">{errors.halalPreferences}</p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="maritalStatus">Marital Status</Label>
        <Select
          value={data.maritalStatus}
          onValueChange={value => updateFields({ maritalStatus: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select marital status" />
          </SelectTrigger>
          <SelectContent>
            {maritalStatusOptions.map(status => (
              <SelectItem key={status} value={status}>
                {status}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.maritalStatus && (
          <p className="mt-1 text-sm text-red-500">{errors.maritalStatus}</p>
        )}
      </div>

      <div>
        <Label>Acceptable Marital Statuses</Label>
        <div className="mt-2 space-y-2">
          {maritalStatusOptions.map(status => (
            <div key={status} className="flex items-center space-x-2">
              <Checkbox
                id={`accept-${status}`}
                checked={data.acceptableMaritalStatuses.includes(status)}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateFields({
                      acceptableMaritalStatuses: [...data.acceptableMaritalStatuses, status],
                    })
                  } else {
                    updateFields({
                      acceptableMaritalStatuses: data.acceptableMaritalStatuses.filter(
                        s => s !== status
                      ),
                    })
                  }
                }}
              />
              <Label htmlFor={`accept-${status}`}>{status}</Label>
            </div>
          ))}
        </div>
        {errors.acceptableMaritalStatuses && (
          <p className="mt-1 text-sm text-red-500">{errors.acceptableMaritalStatuses}</p>
        )}
      </div>

      <div>
        <Label>Do you have children?</Label>
        <RadioGroup
          value={data.hasChildren ? 'yes' : 'no'}
          onValueChange={(value) => updateFields({ hasChildren: value === 'yes' })}
          className="mt-2 flex space-x-4"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="yes" id="has-children-yes" />
            <Label htmlFor="has-children-yes">Yes</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="no" id="has-children-no" />
            <Label htmlFor="has-children-no">No</Label>
          </div>
        </RadioGroup>
      </div>

      {data.hasChildren && (
        <div>
          <Label htmlFor="numberOfChildren">Number of Children</Label>
          <Input
            id="numberOfChildren"
            type="number"
            min="0"
            value={data.numberOfChildren}
            onChange={(e) => updateFields({ numberOfChildren: parseInt(e.target.value) })}
          />
          {errors.numberOfChildren && (
            <p className="mt-1 text-sm text-red-500">{errors.numberOfChildren}</p>
          )}
        </div>
      )}

      <div>
        <Label htmlFor="maxAcceptableChildren">Maximum Acceptable Number of Children</Label>
        <Input
          id="maxAcceptableChildren"
          type="number"
          min="0"
          value={data.maxAcceptableChildren}
          onChange={(e) => updateFields({ maxAcceptableChildren: parseInt(e.target.value) })}
        />
      </div>

      <div>
        <Label htmlFor="polygamyPreference">Polygamy Preference</Label>
        <Select
          value={data.polygamyPreference}
          onValueChange={value => updateFields({ polygamyPreference: value as 'open' | 'closed' | 'seeking' })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select polygamy preference" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="open">Open to polygamy</SelectItem>
            <SelectItem value="closed">Not open to polygamy</SelectItem>
            <SelectItem value="seeking">Seeking additional wife</SelectItem>
          </SelectContent>
        </Select>
        {errors.polygamyPreference && (
          <p className="mt-1 text-sm text-red-500">{errors.polygamyPreference}</p>
        )}
      </div>

      {data.gender === 'female' && (
        <div>
          <Label>Is polygamy a deal breaker?</Label>
          <RadioGroup
            value={data.isPolygamyDealBreaker ? 'yes' : 'no'}
            onValueChange={(value) => updateFields({ isPolygamyDealBreaker: value === 'yes' })}
            className="mt-2 flex space-x-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id="polygamy-deal-breaker-yes" />
              <Label htmlFor="polygamy-deal-breaker-yes">Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id="polygamy-deal-breaker-no" />
              <Label htmlFor="polygamy-deal-breaker-no">No</Label>
            </div>
          </RadioGroup>
        </div>
      )}

      <div className="flex justify-between space-x-4">
        <Button type="button" variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button
          type="submit"
          className="bg-gradient-to-r from-[#FF1493] to-[#1E90FF]"
        >
          Continue
        </Button>
      </div>
    </form>
  )
}

