import { useState } from 'react'
import { motion, useMotionValue, useTransform } from 'framer-motion'
import { ProfileCard } from './ProfileCard'

interface SwipeableCardProps {
  profile: {
    id: string
    name: string
    age: number
    bio: string
    photo: string
  }
  onSwipe: (direction: 'left' | 'right') => void
}

export function SwipeableCard({ profile, onSwipe }: SwipeableCardProps) {
  const [exitX, setExitX] = useState<number | null>(null)
  const x = useMotionValue(0)
  const rotate = useTransform(x, [-200, 200], [-20, 20])
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0, 1, 1, 1, 0])

  const handleDragEnd = (event: any, info: any) => {
    if (info.offset.x < -100) {
      setExitX(-1000)
      onSwipe('left')
    } else if (info.offset.x > 100) {
      setExitX(1000)
      onSwipe('right')
    }
  }

  return (
    <motion.div
      style={{ x, rotate, opacity }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      animate={exitX !== null ? { x: exitX } : undefined}
      className="absolute cursor-grab active:cursor-grabbing"
    >
      <ProfileCard {...profile} />
    </motion.div>
  )
}

