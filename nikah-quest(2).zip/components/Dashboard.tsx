'use client'

import { useState } from 'react'
import { SwipeableCard } from './SwipeableCard'
import { InteractiveButtons } from './InteractiveButtons'
import { MatchRecommendations } from './MatchRecommendations'
import { mockProfiles } from '@/lib/mockData'

export function Dashboard() {
  const [currentProfileIndex, setCurrentProfileIndex] = useState(0)

  const handleSwipe = (direction: 'left' | 'right') => {
    console.log(`Swiped ${direction} on ${mockProfiles[currentProfileIndex].name}`)
    setCurrentProfileIndex((prevIndex) => (prevIndex + 1) % mockProfiles.length)
  }

  const handleLike = () => {
    console.log(`Liked ${mockProfiles[currentProfileIndex].name}`)
    setCurrentProfileIndex((prevIndex) => (prevIndex + 1) % mockProfiles.length)
  }

  const handleSuperLike = () => {
    console.log(`Super Liked ${mockProfiles[currentProfileIndex].name}`)
    setCurrentProfileIndex((prevIndex) => (prevIndex + 1) % mockProfiles.length)
  }

  const handlePass = () => {
    console.log(`Passed on ${mockProfiles[currentProfileIndex].name}`)
    setCurrentProfileIndex((prevIndex) => (prevIndex + 1) % mockProfiles.length)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black p-8">
      <h1 className="mb-8 text-center text-4xl font-bold text-white">NikahQuest</h1>
      <div className="relative mx-auto h-[500px] w-full max-w-[350px]">
        {mockProfiles.map((profile, index) => (
          <SwipeableCard
            key={profile.id}
            profile={profile}
            onSwipe={handleSwipe}
            style={{
              display: index === currentProfileIndex ? 'block' : 'none',
            }}
          />
        ))}
      </div>
      <InteractiveButtons
        onLike={handleLike}
        onSuperLike={handleSuperLike}
        onPass={handlePass}
      />
      <MatchRecommendations
        recommendations={mockProfiles.slice(0, 5).map(p => ({ id: p.id, name: p.name, photo: p.photo }))}
      />
    </div>
  )
}

