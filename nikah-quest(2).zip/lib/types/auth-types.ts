export type SignUpFormData = {
  // Step 1: Create Account
  name: string;
  email: string;
  password: string;
  phoneNumber: string;
  
  // Step 2: Profile Details
  gender: 'male' | 'female';
  preferredMatch: 'male' | 'female';
  dateOfBirth: Date | null;
  sect: string;
  prayerHabits: string;
  halalPreferences: string;
  
  // Step 3: Photos
  photos: string[];
  
  // Step 4: Personal Preferences
  ageRange: [number, number];
  locationRadius: number;
  interests: string[];

  // New fields
  maritalStatus: string;
  acceptableMaritalStatuses: string[];
  hasChildren: boolean;
  numberOfChildren: number;
  maxAcceptableChildren: number;
  polygamyPreference: 'open' | 'closed' | 'seeking';
  isPolygamyDealBreaker: boolean;

  // New field for liveness verification
  livenessVerified: boolean;
}

export type StepProps = {
  data: SignUpFormData;
  updateFields: (fields: Partial<SignUpFormData>) => void;
  onNext: () => void;
  onBack?: () => void;
}

