export const mockProfiles = [
  {
    id: '1',
    name: 'Aisha',
    age: 28,
    bio: 'Passionate about Islamic art and calligraphy. Looking for a partner who shares my love for creativity and faith.',
    photo: '/placeholder.svg?height=400&width=300',
  },
  {
    id: '2',
    name: 'Yusuf',
    age: 32,
    bio: 'Software engineer by day, hafiz by night. Seeking a life partner to build a strong Muslim household.',
    photo: '/placeholder.svg?height=400&width=300',
  },
  {
    id: '3',
    name: 'Fatima',
    age: 26,
    bio: 'Medical student with a passion for community service. Looking for someone who values education and giving back.',
    photo: '/placeholder.svg?height=400&width=300',
  },
  {
    id: '4',
    name: 'Omar',
    age: 30,
    bio: 'Entrepreneur and fitness enthusiast. Searching for a partner who values health, ambition, and strong Islamic principles.',
    photo: '/placeholder.svg?height=400&width=300',
  },
  {
    id: '5',
    name: 'Zainab',
    age: 29,
    bio: 'Environmental scientist and nature lover. Hope to find a spouse who cares about our planet and follows the eco-friendly teachings of Islam.',
    photo: '/placeholder.svg?height=400&width=300',
  },
];

